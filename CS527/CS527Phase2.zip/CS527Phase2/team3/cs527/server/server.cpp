/*
*
* Server
* 
* @Authors: Wyatt Dahlenburg
* 
* A server designed to allow clients to use a limited subset of commands. 
* It may or may not be secure ¯\_(ツ)_/¯
*
*/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <fstream>
#include <iostream>
#include <sstream>
#include <map>

using namespace std;

struct settings_storage {
  char * base;
  int port;
  map<char *, char*> users;
  map<char *, char*> alias;
} settings;

int QueueLength = 5;
bool goodLogin = false;

void setup()
{
  string line;
  ifstream config( "sploit.conf" );
  if (config)
    {
    while (getline( config, line ))
      {
        //Check if line is not a comment
        if (line[0] != '#')
          {
            //Parse the first word
            string word;

            istringstream iss(line, istringstream::in);

            while(iss >> word)     
            {
              char * tmp = const_cast<char *>(word.c_str());
              if (strcmp(tmp, "base") == 0 )
              {
                //Store var into base, port, user, and alias
                
                  //Scan the next word
                  iss >> word;
                  settings.base = strdup(const_cast<char *>(word.c_str()));

                  //Don't scan any more and just move to the next line

                  printf("Base is: \"%s\"\n", settings.base);

                  break;
              }
              else if (strcmp(tmp, "port") == 0)
              {
                  //Scan the port
                  iss >> word;

                  printf("Port: %s\n", word.c_str());
                  //Check to make sure the string is a number
                  int port = stoi (word);

                  //Set the port value
                  settings.port = port;

                  break;
              }
              else if (strcmp(tmp, "user") == 0)
              {
                  //Scan the username
                  iss >> word;
                  char * username = strdup(const_cast<char *>(word.c_str()));

                  //Scan the password
                  iss >> word;
                  char * password = strdup(const_cast<char *>(word.c_str()));

                  printf("User: %s, Pass: %s\n", username, password);

                  settings.users.insert( pair<char*, char*>(username, password));
                  break;
              }
              else if (strcmp(tmp, "alias") == 0)
              {
                //Alias can have n parameters so we just store the map value as all parameters and will do parsing prior to execution

                //Scan the alias
                iss >> word;
                char * al = strdup(const_cast<char *>(word.c_str()));

                //Scan the param
                string params(iss.str().substr(iss.tellg()));
               
                //Remove leading whitespace because we don't parse the final part of the string
                char * parameters = strdup(const_cast<char *>(params.substr(1, params.length()).c_str()));

                printf("Alias: %s, Params: %s\n", al, parameters);

                settings.alias.insert( pair<char*, char*>(al, parameters));
                break;
              }
            }
          }
      }
      config.close();
    }
}

// Processes time request
void processTimeRequest( int socket, char * uName);
void getCmd( int socket, char buf[], char * uName);

char * help()
{
  return "Help message!\n";
}

int main( int argc, char ** argv )
{

  setup();

  // Print usage if not enough arguments
  if ( settings.port < 0 || settings.port > 65535 ) {
    fprintf( stderr, "%s", help() );
    exit( -1 );
  }
  
  // Get the port from the arguments
  int port = settings.port;
  
  // Set the IP address and port for this server
  struct sockaddr_in serverIPAddress; 
  memset( &serverIPAddress, 0, sizeof(serverIPAddress) );
  serverIPAddress.sin_family = AF_INET;
  serverIPAddress.sin_addr.s_addr = INADDR_ANY;
  serverIPAddress.sin_port = htons((u_short) port);
  
  // Allocate a socket
  int masterSocket =  socket(PF_INET, SOCK_STREAM, 0);
  if ( masterSocket < 0) {
    perror("socket");
    exit( -1 );
  }

  // Set socket options to reuse port. Otherwise we will
  // have to wait about 2 minutes before reusing the sae port number
  int optval = 1; 
  int err = setsockopt(masterSocket, SOL_SOCKET, SO_REUSEADDR, 
		       (char *) &optval, sizeof( int ) );
   
  // Bind the socket to the IP address and port
  int error = bind( masterSocket,
		    (struct sockaddr *)&serverIPAddress,
		    sizeof(serverIPAddress) );
  if ( error ) {
    perror("bind");
    exit( -1 );
  }
  
  // Put socket in listening mode and set the 
  // size of the queue of unprocessed connections
  error = listen( masterSocket, QueueLength);
  if ( error ) {
    perror("listen");
    exit( -1 );
  }
  
  char login_uName[2] = {'\0'};
  strncpy(login_uName, " ", 1);
  
  while ( 1 ) {

    // Accept incoming connections
    struct sockaddr_in clientIPAddress;
    int alen = sizeof( clientIPAddress );
    int slaveSocket = accept( masterSocket,
			      (struct sockaddr *)&clientIPAddress,
			      (socklen_t*)&alen);
    if ( slaveSocket < 0 ) {
      perror( "accept" );
      exit( -1 );
    }
    // Process request.
    processTimeRequest( slaveSocket,  login_uName);

    // Close socket
    close( slaveSocket );
    
  }
  
}

void processTimeRequest( int fd , char * m_login_uName)
{

  // Send Greeting
  const char * welcome = "\nWelcome to my server!\n";
  write( fd, welcome, strlen( welcome ) );

  // Buffer used to store the name received from the client
  const int MaxBuffer = 1024;
  char buffer[ MaxBuffer + 1 ];
  int bufferLength = 0;
  int n;

  // Send prompt
  const char * prompt = "\nEnter input: ";
  write( fd, prompt, strlen( prompt ) );

  // Currently character read
  unsigned char newChar;

  //
  // The client should send <buffer><<lf>
  // Read the name of the client character by character until a
  // <LF> is found.
  //
    
  while ( bufferLength < MaxBuffer &&
    ( n = read( fd, &newChar, sizeof(newChar) ) ) > 0 ) {

    if ( newChar == '\012' ) {
      break;
    }

    buffer[ bufferLength ] = newChar;
    bufferLength++;
  }

  // Add null character at the end of the string
  buffer[ bufferLength ] = 0;

  printf( "buffer=%s\n", buffer );
  
  getCmd(fd, buffer, m_login_uName);
}

void getCmd(int fd, char cmd[], char * mm_login_uName)
{
  int defout = dup(1);
  dup2(fd,1);
  if(strcmp(cmd, "ls") == 0)
  {
    if(goodLogin)
    {
      system("ls -l");
    }
    else
    {
      const char * not_allowed = "Error: Command not allowed.\n";
      write( fd, not_allowed, strlen( not_allowed ) );
    }
  }
  else if(strncmp(cmd, "ping", 4) == 0)
  {
    system(strcat(cmd," -c 1"));
  }
	else if(strncmp(cmd, "cd", 2) == 0)
  {
		if(goodLogin)
    {
      system(cmd);
    }
    else
    {
      const char * not_allowed = "Error: Command not allowed.\n";
      write( fd, not_allowed, strlen( not_allowed ) );
    }
  }
	else if(strncmp(cmd, "date", 4) == 0)
  {
		if(goodLogin)
    {
      system("date");
    }
    else
    {
      const char * not_allowed = "Error: Command not allowed.\n";
      write( fd, not_allowed, strlen( not_allowed ) );
    }
  }
	else if(strncmp(cmd, "whoami", 6) == 0)
  {
		if(goodLogin)
    {
      char * whoami_output = mm_login_uName;
      char output[2]={'\n', '\0'};
      strncat (whoami_output, output, 2);
      write( fd, whoami_output, strlen( whoami_output ) );
    }
    else
    {
      const char * not_allowed = "Error: Command not allowed.\n";
      write( fd, not_allowed, strlen( not_allowed ) );
    }
  }
	else if(strncmp(cmd, "login", 5) == 0)
  {
    //user attempting to login
    const char s[2] = " ";
    char *parts;
    parts = strtok(cmd, s);

    int i = 0;
    char *tmp_uName;
    while( parts != NULL ) 
    {
      if(i == 1)
      {
        tmp_uName = parts;
      }
      i++;
      parts = strtok (NULL, s);
    }
    if(goodLogin && strncmp(mm_login_uName, tmp_uName, strlen(mm_login_uName)) == 0)
    {
        printf("Hi %s! You are already logged in.\n", mm_login_uName);
    }
    else
    {
      if(i == 2) //correct # para
      {
        bool notFound = false;
        for(map<char*, char*>::iterator p = settings.users.begin(); p!= settings.users.end(); ++p) 
        {
          if(strncmp(p->first, tmp_uName, strlen(p->first)) == 0)
          {
            mm_login_uName[strlen(tmp_uName)+1] = {'\0'};
            strncpy(mm_login_uName, tmp_uName, strlen(tmp_uName));
            const char * login_output = "Please enter password by using the pass $password command.\n";
            write( fd, login_output, strlen( login_output ) );
            break;
          }
          notFound = true;
        }
        if (notFound)
        {
          const char * login_output = "Invalid user.\n";
          write( fd, login_output, strlen( login_output ) );
        }
      }
      else
      {
        const char * login_output = "Usage: login $username\n";
        write( fd, login_output, strlen( login_output ) );
      }
    }
  }
  else if(strncmp(cmd, "pass", 4) == 0)
  {
    if(strncmp(mm_login_uName, " ", 1) == 0)
    {
      printf("No username detected. Please re-login with login $username command.\n"); 
    }
    else
    {
      const char s[2] = " ";
      char *parts;
      parts = strtok(cmd, s);

      int i = 0;
      char *tmp_uPass;
      while( parts != NULL ) 
      {
        if(i == 1)
        {
          tmp_uPass = parts;
        }
        i++;
        parts = strtok (NULL, s);
      }

      if(i == 2) //correct # para
      {
        bool m_goodLogin = false;
        for(map<char*, char*>::iterator p = settings.users.begin(); p!= settings.users.end(); ++p) 
        {
          if(strncmp(p->first, mm_login_uName, strlen(p->first)) == 0)
          {
            if(strncmp(p->second, tmp_uPass, strlen(p->second)) == 0)
            {
              m_goodLogin = true;
            }
            break;
          }
        }
        if (m_goodLogin)
        {
          goodLogin = true;
          printf("Hi %s!\n", mm_login_uName);
        }
        else
        {
          printf("Incorrect password. Please re-login with login $username command.\n");
          mm_login_uName[2] = {'\0'};
          strncpy(mm_login_uName, " ", 1);
          goodLogin = false;
        }
      }
      else
      {
        printf("Usage: pass $password. Please re-login with login $username command (you will be logged out if you are currently logged in).\n"); 
        if(!goodLogin)
        {
          mm_login_uName[2] = {'\0'};
          strncpy(mm_login_uName, " ", 1);
        }
      }
    }
  }
  dup2(defout, 1);
}