/*
*
* Client
* 
* @Authors: Wyatt Dahlenburg
* 
* A simple client designed to connect to the server for CS527. 
*
*/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

void help()
{
  printf( "Usage: client <server-ip> <server-port>\n");
  printf( "\n");
  printf( "          server-host: host where the server is running.\n");
  printf( "          server-port: port that the server is using.\n");
  printf( "\n");
}

int main(int argc, char **argv)
{
  // Ensure the server and port are given as command line input 
  if ( argc < 3 ) {
    help();
    exit(1);
  }

  // Extract host name
  char * host = argv[1];

  // Extract port number
  int port = atoi(argv[2]);

  // Initialize socket address structure
  struct  sockaddr_in socketAddress;

  // Clear sockaddr structure
  memset((char *)&socketAddress, 0, sizeof(socketAddress));

  // Set family to Internet 
  socketAddress.sin_family = AF_INET;

  // Test for port legal value
  if (port > 0) {
    socketAddress.sin_port = htons((u_short)port);
  }
  else {
    fprintf(stderr,"Bad port number %s\n", argv[2]);
    exit(1);
  }

  // Get host table entry for this host
  struct  hostent  *ptrh = gethostbyname(host);
  if ( ptrh == NULL ) {
    fprintf(stderr, "Invalid host: %s\n", host);
    perror("gethostbyname");
    exit(1);
  }

  // Copy the host ip address to socket address structure
  memcpy(&socketAddress.sin_addr, ptrh->h_addr, ptrh->h_length);

  // Get TCP transport protocol entry
  struct  protoent *ptrp = getprotobyname("tcp");
  if ( ptrp == NULL ) {
    fprintf(stderr, "Cannot map tcp to protocol number");
    perror("getprotobyname");
    exit(1);
  }
  
  // Create a tcp socket
  int sock = socket(PF_INET, SOCK_STREAM, ptrp->p_proto);
  if (sock < 0) {
    fprintf(stderr, "Socket creation failed\n");
    perror("Socket");
    exit(1);
  }

  // Connect the socket to the specified server
  if (connect(sock, (struct sockaddr *)&socketAddress,
	      sizeof(socketAddress)) < 0) {
    fprintf(stderr,"connect failed\n");
    perror("connect");
    exit(1);
  }

  // In this application we don't need to send anything.
  // For your HTTP client you will need to send the request
  // as specified in the handout using send().
  char buffer[100+1];
  int m = read(sock,buffer,100);
  buffer[m]=0;
  printf("Server says: %s", buffer);

  char * str;
  str= (char*)calloc(256,sizeof(char));
  fgets(str,256,stdin);

  write(sock, str, strlen(str));
  write(sock,"\r\n",2);

  // Receive reply

  // Data received
  char buf[1000];
  int n = recv(sock, buf, sizeof(buf), 0);
  while (n > 0) {
    // Write n characters to stdout
    write(1,buf,n);

    // Continue receiving more
    n = recv(sock, buf, sizeof(buf), 0);
  }

  // Close the socket.
  close(sock);

  // Terminate the client program gracefully.
  exit(0);
}
