#ifndef _UTILS_H_
#define _UTILS_H_
#include <string>
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <regex.h>
#include <arpa/inet.h>
#include <map>
#include <vector>
#include <time.h>

#define NAME_LEN    64
#define TIMEOUT     3405691582
#define NUM_THREADS 24
#define MAXPORT 	65535
#define MINPORT		1024
#define MAXSIZE 	1024
#define PORT_ERR	-1
#define SIZE_ERR	-2
#define MATCH_NO	-3
#define MATCH_ERR	-4
#define PORT_RD		44444
#define PORT_WR		33333
#define PORT_RD_RANGE	24
#define PORT_WR_RANGE	24
#define MAX_FSIZE       1024*1024

struct arg{
    char name[NAME_LEN];
    char *buf;
    long size;
    int sock;
};

struct config{
    std::string currentPath = ".";
    int port;
    std::map <std::string, std::string> alias;
    std::map <std::string, std::string> usermap;
    std::vector<std::string> history;
    char whoami_cmd[25] = "whoami";
    char date_cmd[25] = "date";
    char exit_cmd[25] = "exit";
    char logout_cmd[25] = "logout";
    char cd_cmd[25] = "chdir";
    char ls_cmd[25] = "ls";
    char errmsg[2048] = {0};
    char start_time[20];
    char get_format[25] = "get port: %d size: %d";
    char put_format[25] = "put port: %d";
    int read_port = PORT_RD;
    int write_port = PORT_WR;
};

const int n = 100;
extern char command_buf[n];

std::string receive_message(int sock);

int send_message(int sock, std::string);

std::string trim(const std::string& str);
regex_t compile_regex(std::string);

int matches(regex_t, std::string);

int has_special_characters(const char *);

int bind_to_socket(int, struct sockaddr_in *, socklen_t *);

std::string run_cmd(std::string cmd);

void get_time(char *buf);
int is_clean_command(const char *, int);

#endif /* _UTILS_H_ */
