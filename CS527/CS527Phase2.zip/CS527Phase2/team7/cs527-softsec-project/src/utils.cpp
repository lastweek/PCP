
#include "utils.h"
#include <unistd.h>

using namespace std;

char command_buf[n];

const char *legal_commands_regex = "^(cd|date|l(og(in|out)|s)|get|ex(i|pec)t|p(ass|ing|ut)|whoami|w|weather)";

// Recv message from sock and return it.
string receive_message(int sock) {
    if (!sock){
        cout << "ERROR stream is NULL" << endl;
        exit(0);
    }

    char buf[2048];
    string s = "";
    int c_read = 0;
    while((c_read=read(sock, buf, 2047)) == 2047){
        buf[2048] = 0;
        s += buf;
    }
    buf[c_read] = 0;
    s += buf;
    return s;
}

// Send message to sock.
int send_message(int sock, string message) {
    if (!sock){
        cout << "ERROR stream is NULL" << endl;
        exit(0);
    }
    return write(sock, message.c_str(), message.size());
}

// Remove the whitespace from str.
string trim(const string& str){
    string whitespace = " \n\r\t";
    const size_t strBegin = str.find_first_not_of(whitespace);
    if (strBegin == string::npos)
        return ""; // no content

    const size_t strEnd = str.find_last_not_of(whitespace);
    const size_t strRange = strEnd - strBegin + 1;

    return str.substr(strBegin, strRange);
}

void clear_buf(){
    for (int i = 0; i < n; i++){
        command_buf[i] = '\0';
    }
}

// Wrapper for regcomp.
regex_t compile_regex(const char *regex_string){
    regex_t regex;
    int r;
    if ((r = regcomp(&regex, regex_string, REG_EXTENDED))) {
        char errbuf[1024];
        regerror(r, &regex, errbuf, sizeof(errbuf));
        printf("error: %s\n", errbuf);
        exit(1);
    }
    return regex;
}

// Wrapper for regexec.
int matches(regex_t regex, const char *s){
    return regexec(&regex, s, 0, NULL, 0) != REG_NOMATCH;
}

int match_size(regex_t regex, const char *s){
    const size_t maxGroups = 1;
    regmatch_t groupArray[maxGroups];
    if (regexec(&regex, s, maxGroups, groupArray, 0) != REG_NOMATCH){
        return groupArray[0].rm_eo - groupArray[0].rm_so;
    } else {
        return -1;
    }
}

int has_special_characters(const char *command){
    if (matches(compile_regex("[`$()|><&]"), command)){
        return true;
    } else {
        return false;
    }
}

int is_forbidden_command(const char *input){
    // (regexp-opt '("sh" "zsh" "bash" "ksh" "wget" "expect" "rbash" "rksh" "sudo" "python" "perl" "ruby" "ed" "ne" "nano" "pico" "vim" "more" "less" "man" "vi" "nc" "links" "mutt" "find" "awk" "php"))

    const char *forbidden_commands_regex = "(awk|bash|e(d|xpect)|find|ksh|l((es|ink)s)|m(an|ore|utt)|n(ano|[ce])|p(erl|hp|ico|ython)|r(bash|ksh|uby)|s(h|udo)|vim?|wget|zsh)";
    // const char *forbidden_commands_regex = "(bash|ksh|sh|expect|wget|zsh|rbash|rksh|)";
    return matches(compile_regex(forbidden_commands_regex), input);
}

int is_legal_command(const char *input){
    regex_t re = compile_regex(legal_commands_regex);
    return matches(re, input);
}

int is_clean_command(const char *input, int length){
    regex_t re = compile_regex(legal_commands_regex);
    if (is_forbidden_command(input)
        || has_special_characters(strncpy(command_buf, input, length))){
        clear_buf();
        return 0;
    }

    if (!is_legal_command(command_buf)){
        return 0;
    } else {
        // Clear the buffer.
        for (int i = match_size(re, command_buf); i < n; i++){
            command_buf[i] = '\0';
        }
        return 1;
    }
}

//	Get, bind and listen the socket for address:port. Also setsockopt(SO_REUSEADDR).
int bind_to_socket(int port, struct sockaddr_in *address, socklen_t *addlen){
    memset (address, 0, sizeof(*address));
    address->sin_family = AF_INET;
    address->sin_port = htons(port);
    int sd = socket(AF_INET, SOCK_STREAM, 0);
    int yes = 1;

    // Avoid the "bind failed" error when rerunning the server after a crash.
    if (setsockopt(sd, SOL_SOCKET, SO_REUSEADDR,
                   &yes, sizeof(int)) < 0){
        cout << "setsockopt(SO_REUSEADDR) failed" << endl;
        exit(1);
    }

    int r = bind(sd, (const sockaddr *)address, (socklen_t)*addlen);
    if(r < 0){
        printf("bind failed\n");
        exit(1);
    }
    r = listen(sd, 3);
    if(r < 0){
        printf("listen failed\n");
        exit(1);
    }
    return sd;
}

// Run cmd as shell commands and return the result.
string run_cmd(string cmd){
    char buffer[128];
    string result = "";
    FILE* pipe = popen((cmd + " 2>&1").c_str(), "r");
    if (!pipe) throw runtime_error("popen() failed!");
    try {
        while (!feof(pipe)) {
            if (fgets(buffer, 128, pipe) != NULL)
                result += buffer;
        }
    } catch (...) {
        pclose(pipe);
        throw;
    }
    pclose(pipe);
    return result;
}

void get_time(char *buf){
    time_t timer;
    struct tm* tm_info;
    time(&timer);
    tm_info = localtime(&timer);
    strftime(buf, 20, "%Y-%m-%d %H:%M:%S", tm_info);
    buf[19] = 0;
}
