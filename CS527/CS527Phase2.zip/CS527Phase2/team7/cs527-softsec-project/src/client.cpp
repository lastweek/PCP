/*
   client.cpp

   Test client for the tcpsockets classes.

   ------------------------------------------

   Copyright (c) 2013 Vic Hargrave

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

#include <iostream>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include "utils.h"
#include <arpa/inet.h>
#include <unistd.h>
#include <pthread.h>

using namespace std;

static string host;

//  Receive contents from the server and write to local files with parameters.
//  defined in args.
void * recv_file(void *args){
    struct arg * s_arg = (struct arg *)args;
    int sock = s_arg->sock;
    long size = s_arg->size;
    char *buf = (char *)malloc(size);
    if(read(sock, buf, size) < 0){
        cout << "read failed\n";
    }
    else {
        FILE *f = fopen(s_arg->name, "wb");
        fwrite(buf, size, 1, f);
        fclose(f);
        cout << "File received" << endl;
    }
    close(sock);
    free(buf);
    free(args);
    return NULL;
}

//  Receive file from the server and spawn a thread of recv_file.
void receive_file(int port, long size, string& file_name){
    struct sockaddr_in address;
    memset(&address, 0, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_port = htons(port);
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if(sock < 0){
        cout << "socket error" << endl;
    }
    if(inet_pton(AF_INET, host.c_str(), &address.sin_addr)<=0)
    {
        printf("\nInvalid address/ Address not supported \n");
    }
    if (connect(sock, (struct sockaddr *)&address, sizeof(address)) == 0) {
        pthread_t t_id;
        struct arg *args = (struct arg *)malloc(sizeof(struct arg));
        args->size = size;
        args->sock = sock;
        // args->name = file_name;
        snprintf(args->name, NAME_LEN, "%s", trim(file_name).c_str());
        pthread_create(&t_id, NULL, recv_file, (void *)args);
    } else{
        cout << "conn failed" << endl;
    }
}

//  Parse and get the size from string& line.
long parse_size(string& line){
    return atol(line.substr(line.find("size")+6).c_str());
}

//  Parse and get port from string& line.
int parse_port(string& line){
    return atoi(line.substr(line.find("port")+6, 5).c_str());
}

//  Parse and get the file name from string& msg.
string get_file_name(string& msg){
    return msg.substr(msg.find(' '));
}

//  Read contents from local files.
char * read_file(string& name, long *size){
    FILE *f = fopen(name.c_str(), "rb");
    if(!f){
        cout << "file open error" << endl;
        return 0;
    }
    fseek(f, 0, SEEK_END);
    long fileLen = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *buffer = (char *)malloc(fileLen);
    if (!buffer)
    {
        cout << "memory error" << endl;
        fclose(f);
        return 0;
    }
    cout << "read" << endl;
    fread(buffer, fileLen, 1, f);
    fclose(f);
    *size = fileLen;
    return buffer;
}

//  Write buf to sock. All parametes are specified in args.
void * write_sock(void *args){
    struct arg *s_arg = (struct arg *)args;
    write(s_arg->sock, s_arg->buf, s_arg->size);
    cout << "sent" << endl;
    close(s_arg->sock);
    free(s_arg->buf);
    free(args);
    return NULL;
}

//  Connect the socket of address:port and spawn a thread of write_sock.
void write2sock(string name, int port){
    struct sockaddr_in address;
    memset(&address, 0, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_port = htons(port);
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if(sock < 0){
        cout << "socket error" << endl;
    }
    if(inet_pton(AF_INET, host.c_str(), &address.sin_addr)<=0)
    {
        printf("\nInvalid address/ Address not supported \n");
    }
    long size;
    char *buf = read_file(name, &size);
    if (connect(sock, (struct sockaddr *)&address, sizeof(address)) == 0) {
        pthread_t t_id;
        struct arg *args = (struct arg *)malloc(sizeof(struct arg));
        args->size = size;
        args->sock = sock;
        args->buf = buf;
        pthread_create(&t_id, NULL, write_sock, (void *)args);
    } else{
        cout << "conn failed" << endl;
    }
}

//  Get the input from the user, parse it and then send the approporiate message
//  to the server. Receive and send files if needed.
int interact_with_server(int sock){
    if (!sock){
        return 1;
    }

    string message;
    while(getline(cin, message)){
        message += "\n";
        send_message(sock, message);
        if(message == "exit\n"){
            receive_message(sock);
            exit(0);
        }
        string response = receive_message(sock);
        if(response.find("get") != string::npos){
            int port = parse_port(response);
            string tmp = trim(response);
            long size = parse_size(tmp);
            tmp = trim(message);
            string name = get_file_name(tmp);
            sleep(2);
            receive_file(port, size, name);
        }
        if(response.find("put") != string::npos){
            cout << "recv: " << response << endl;
            int port = atoi(response.substr(response.find_last_of(' ')+1, 5).c_str());
            int p1 = message.find_first_of(' ')+1;
            int p2 = message.find_last_of(' ');
            string name = message.substr(p1, p2-p1);
            write2sock(name, port);
        }
        cout << response;
    }
    return 0;
}

// Main function of client. Parse port and ip from the argv and connect to that
//  ip:port then interact_with_server.
int main(int argc, char** argv)
{
    ifstream input;
    ofstream output_file;
    if (argc != 3 && argc != 5) {
        printf("usage: %s <ip> <port> [infile outfile]\n", argv[0]);
        exit(1);
    }

    if (argc == 5){
        input.open(argv[3]);
        if (!input){
            cout << "Error reading " << argv[3] << endl;
            return 1;
        }
        cin.rdbuf(input.rdbuf());
        cin.tie(0); // tied to cout by default

        output_file.open(argv[4]);
        if (!output_file.is_open()) {
            cout << "Unable to open file " << argv[4];
            exit(1);
        }
        cout.rdbuf(output_file.rdbuf());
    }

    host = argv[1];
    int port = atoi(argv[2]);
    struct sockaddr_in address;
    memset(&address, 0, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_port = htons(port);
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if(sock < 0){
        cout << "socket error" << endl;
    }
    if(inet_pton(AF_INET, host.c_str(), &address.sin_addr)<=0)
    {
        printf("\nInvalid address/ Address not supported \n");
        return -1;
    }
    if (connect(sock, (struct sockaddr *)&address, sizeof(address)) == 0) {
        interact_with_server(sock);
    }
    exit(0);
}
