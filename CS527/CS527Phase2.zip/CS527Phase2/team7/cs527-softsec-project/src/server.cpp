/*
   server.cpp

   Test server for the tcpsockets classes which handles connections
   iteratively.

   ------------------------------------------

   Copyright (c) 2013 Vic Hargrave

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

#include <sys/socket.h>
#include <iostream>
#include <stdio.h>
#include <stdexcept>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <cassert>
#include <sstream>
#include <fstream>
#include <map>
#include <vector>
#include <functional>
#include "utils.h"
#include <arpa/inet.h>
#include <pthread.h>
#include <mutex>

using namespace std;

static std::mutex mtx_rd;
static std::mutex mtx_wr;


static struct config conf;
//	Check if it is TIMEOUT

int check_performance(char *start_time){
    char buf[20];
    get_time(buf);
    buf[19] = 0;
    if(strncmp(buf, start_time, 11) == 0)
        return 1;
    else
        return 0;
}

//	Read the content from filename with length file_len, return buffer
char * read_file(string filename, unsigned long *file_len){
    char namebuf[NAME_LEN];
    strncpy(namebuf, filename.c_str(), NAME_LEN-1);
    string file_name = namebuf;
    string fname = trim(conf.currentPath) + "/" + trim(file_name);
    FILE *f = fopen(fname.c_str(), "rb");
    if(!f){
        cout << "file open error" << endl;
        strcat(conf.errmsg, "No file named: ");
        strcat(conf.errmsg, fname.c_str());
        if(!check_performance(conf.start_time)){
            //err occurs.
            exit(0);
        }
        return 0;
    }
    fseek(f, 0, SEEK_END);
    unsigned long fileLen = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *buffer = (char *)malloc(fileLen+1);
	if (!buffer)
	{
        cout << "memory error" << endl;
        strcat(conf.errmsg, "memory error");
        fclose(f);
		return 0;
	}
    fread(buffer, fileLen, 1, f);
	fclose(f);
    *file_len = fileLen;
    return buffer;
}

// Parse the configuration file, sploit.conf, handle the current path, port,
// allowed users and alias commands.
void parse_config(){
    ifstream conf_in("sploit.conf");
    if(!conf_in){
        cout << "Open configuration file failed.\n";
        exit(1);
    }
    string line;
    string username, passwd;
    while(getline(conf_in, line)){
        line = trim(line);
        if(line.c_str()[0] == '#'){
            continue;
        }
        int space_pos = line.find(' ');
        string direct = line.substr(0, space_pos);
        string direct_cont = line.substr(space_pos+1);
        if(direct == "base"){
            conf.currentPath = direct_cont;
        }
        else if(direct == "port"){
            conf.port = atoi(direct_cont.c_str());
        }
        else if(direct == "user"){
            int u_pos = direct_cont.find(' ');
            username = direct_cont.substr(0, u_pos);
            passwd = direct_cont.substr(u_pos + 1);
            conf.usermap.insert(pair<string, string>(username, passwd));
        }
        else if (direct == "alias"){
            int a_pos = direct_cont.find(' ');
            string alias_cmd = direct_cont.substr(0, a_pos);
            string orgl_cmd = direct_cont.substr(a_pos+1);
            conf.alias.insert(pair<string, string>(alias_cmd, orgl_cmd));
        }
        continue;
    }
    get_time(conf.start_time);
}

//	Write contents to the sock with parameters defined in struct *s_arg.
void * write_file(void *args){
    struct arg *s_arg = (struct arg *)args;
    char *buf = s_arg->buf;
    long f_size = s_arg->size;
    int sock = s_arg->sock;
    write(sock, buf, f_size);
    close(sock);
    free(buf);
    free(args);
    return NULL;
}

//	Setup up the listening socket and spawn a thread of write_file.
int setup_write(char *buf, unsigned long file_len, int port){
    struct sockaddr_in address;
    socklen_t addlen = sizeof(address);
    int sd = bind_to_socket(port, &address, &addlen);

    int f_sock = accept(sd, (sockaddr *)&address, (socklen_t *)&addlen);
    struct arg *s_arg = (struct arg *)malloc(sizeof(struct arg));
    s_arg->buf = buf;
    s_arg->size = file_len;
    s_arg->sock = f_sock;
    pthread_t t_id;
    pthread_create(&t_id, NULL, write_file, (void *)s_arg);
    return 0;
}

//	Function to write buf to file with name and size.
void write2file(char *buf, long size, string name){
    string path = trim(conf.currentPath) + "/" + trim(name);
    FILE *f = fopen(path.c_str(), "wb");
    if(!f){
        cout << "file open error" << endl;
    }
    fwrite(buf, size, 1, f);
    fclose(f);
    free(buf);
}

//	Read file content from sock with paramenters defined in args.
void * read_file_from_sock(void *args){
    struct arg *s_arg = (struct arg *)args;
    char *buf = s_arg->buf;
    int sock = s_arg->sock;
    string f_name = s_arg->name;
    long size = s_arg->size;
    read(sock, buf, size);
    write2file(buf, size, f_name);
    close(sock);
    free(args);
    return NULL;
}

//	Setup up the listening socket and spawn a thread of read_file with file_len
//	file_name specified.
void setup_read(char *buf, long file_len, string file_name, int port){
    struct sockaddr_in address;
    socklen_t addlen = sizeof(address);
    int sd = bind_to_socket(port, &address, &addlen);

    listen(sd, 3);
    int f_sock = accept(sd, (sockaddr *)&address, (socklen_t *)&addlen);
    struct arg *s_arg = (struct arg *)malloc(sizeof(struct arg));
    s_arg->buf = buf;
    s_arg->size = file_len;
    s_arg->sock = f_sock;
    snprintf(s_arg->name, NAME_LEN, "%s", file_name.c_str());
    pthread_t t_id;
    pthread_create(&t_id, NULL, read_file_from_sock, (void *)s_arg);

}

unsigned char check_integrity(char *buf, long file_len){
    char time[20];
    unsigned char cksum = 0;
    char cksumbuf[MAX_FSIZE];
    get_time(time);
    memcpy(cksumbuf, buf, file_len);
    for(int i=0; i<MAX_FSIZE; i++){
        cksum = cksum ^ cksumbuf[i];
    }
    if(check_performance(time))
        return cksum;
    else{
        exit(1);
    }
}

string get_weather(string city){
    char weather[2048];
    string weather_cmd = "wget -q -O- \"http://www.accuweather.com/en/de/" + trim(city)
     + "/10178/weather-forecast/178087\" | awk -F[{}] '/acm_RecentLocationsCarousel.push/{print $2}'";
     cout << weather_cmd << endl;
    string out = run_cmd(weather_cmd);
    cout << out << endl;
    strcpy(weather, out.c_str());
    out = weather;
    return out;
}

// Function to handle commands from one client including login and pass.
void* handle_client(void *socket){
    int sock = *(int*)socket;
    enum state
    {
        NON_LOGIN,
        LOGGING_IN,
        LOGGED_IN
    } s_state;
    string current_uname;
    s_state = NON_LOGIN;
    string result;
    string command;
    string args;
    string commandLine;

    while ((commandLine = receive_message(sock)) != "") {
        if (commandLine == "\n"){
            string error_message = "ERROR blank command\n";
            send_message(sock, error_message);
            continue;
        }

        // Trim trailing whitespace.
        commandLine = trim(commandLine);

        size_t cmd_sep;
        if((cmd_sep = commandLine.find(" ")) == string::npos){
            command = commandLine;
            args = "";
        } else{
            command = commandLine.substr(0, cmd_sep);
            args = commandLine.substr(cmd_sep);
        }

        // Run aliases ignoring any extra arguments.
        if (conf.alias.find(command) != conf.alias.end()){
            command = conf.alias.find(command)->second;
            string message = "Running alias command: " + command;
            result = run_cmd(command);
            send_message(sock, result);
            continue;
        }

        if (!is_clean_command(command.c_str(), command.size())
            || has_special_characters(args.c_str())){
            string message = "ERROR Invalid command\n";
            send_message(sock, message);
            continue;
        } else {
            command = command_buf;
        }

        // These commands don't need authentication.
        if (command == conf.exit_cmd){
            s_state = NON_LOGIN;
            string message = "Bye\n";
            send_message(sock, message);
            continue;
        } else if (command == "ping"){
            string final_command = "ping \"" + trim(args) + "\" -c 1";
            result = run_cmd(final_command);
            send_message(sock, result);
            continue;
        }

        if (s_state == LOGGING_IN){
            if (command != "pass"){
                string error_message = "ERROR expected pass\n";
                send_message(sock, error_message);
            }
            else if (command == "pass"){
                string pass = commandLine.substr(5);
                if(pass == conf.usermap.find(current_uname)->second){
                    s_state = LOGGED_IN;
                    conf.history.push_back(current_uname);
                    string message = "You've logged in\n";
                    send_message(sock, message);
                }else{
                    string error_message = "ERROR wrong username or password\n";
                    send_message(sock, error_message);
                }
            }
        } else if (s_state == NON_LOGIN){
            if (command == "login"){
                current_uname = commandLine.substr(6);
                if(current_uname == ""){
                    string message = "Wrong username\n";
                    send_message(sock, message);
                } else if(conf.usermap.find(current_uname) != conf.usermap.end()){
                    s_state = LOGGING_IN;
                    string message = "Enter password\n";
                    send_message(sock, message);
                } else {
                    string error_message = "ERROR wrong username or password\n";
                    send_message(sock, error_message);
                }
            } else {
                string err_msg = "ERROR command requires authentication\n";
                send_message(sock, err_msg);
            }
        } else {
            assert(s_state == LOGGED_IN);
            if (command == conf.whoami_cmd){
                send_message(sock, current_uname+"\n");
            } else if (command == conf.date_cmd){
                result = run_cmd(conf.date_cmd);
                send_message(sock, result);
            } else if (command == "ls"){
                result = run_cmd(string(conf.ls_cmd) + " -l" + " " + conf.currentPath);
                send_message(sock, result);
            } else if (command == "cd"){
                if(commandLine.size()<=2) {
                    string message = "ERROR Wrong path\n";
                    send_message(sock, message);
                    continue;
                }
                string path = commandLine.substr(3);
                if(chdir(path.c_str()) == 0){
                    conf.currentPath = run_cmd("pwd");
                    send_message(sock, conf.currentPath);
                }else{
                    string message = "ERROR Wrong path\n";
                    send_message(sock, message);
                }
            } else if (command == "get"){
                string filename = args;
                char *buf;
                unsigned long file_len = 0;
                buf = read_file(filename, &file_len);
                if(buf == 0){
                    string err_msg = "No such file\n";
                    send_message(sock, err_msg);
                    continue;
                }
                int port = conf.write_port;
                if(mtx_wr.try_lock()){
                    conf.write_port = (++(conf.write_port)==(PORT_WR_RANGE+PORT_WR))?PORT_WR:conf.write_port;
                    mtx_wr.unlock();
                }

                char get_rsp[128];
                sprintf(get_rsp, conf.get_format, port, file_len);
                string response = get_rsp;
                response += "\n";
                send_message(sock, response);
                check_integrity(buf, file_len);
                setup_write(buf, file_len, port);
            } else if (command == "put"){
                args = trim(args);
                int pos = args.find(" ");
                string filename = args.substr(0, pos);
                long size = atol(args.substr(pos+1).c_str());
                int port= conf.read_port;
                if(mtx_rd.try_lock()){
                    conf.read_port= (++(conf.read_port)==(PORT_RD_RANGE+PORT_RD))?PORT_RD:conf.read_port;
                    mtx_rd.unlock();
                }
                string response = "put port: "+to_string(port)+"\n";
                send_message(sock, response);
                char *buf = (char *)malloc(size);
                setup_read(buf, size, filename, port);
            } else if (command == "logout"){
                s_state = NON_LOGIN;
                string message = "You've logged out\n";
                send_message(sock, message);
            } else if (command == "w"){
                result = "";
                vector<string>::const_iterator i;
                for(i=conf.history.begin(); i!=conf.history.end(); i++){
                    result += (*i);
                    result += " ";
                }
                result = result.substr(0, result.size()-1);
                result += "\n";
                send_message(sock, result);
            } else if (command == "weather"){
                string weather = get_weather(args);
                send_message(sock, weather);
            }else{
                result = run_cmd(command + args);
                send_message(sock, result);
            }
        }
    }
    close(sock);
    pthread_exit(NULL);
}

// Create at most NUM_THREADS threads to deal with multiple clients.
// Read the configuration file when the server starts.
int main()
{
    parse_config();
    struct sockaddr_in address;
    socklen_t addlen = sizeof(address);
    int sd = bind_to_socket(conf.port, &address, &addlen);

    int noThread=0;
    pthread_t threadA[NUM_THREADS];
    while (noThread < NUM_THREADS) {
        int sock = accept(sd, (struct sockaddr *)&address, (socklen_t*)&addlen);
        if(sock!=0){
            pthread_create(&threadA[noThread], NULL, handle_client, (void*)&sock);
            noThread++;
        }
    }
    close(sd);
    exit(0);
}
