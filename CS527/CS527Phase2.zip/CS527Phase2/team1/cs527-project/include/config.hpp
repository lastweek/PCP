#ifndef CS527_PROJECT_CONFIG_HPP
#define CS527_PROJECT_CONFIG_HPP

#include <string>
#include <utility>
#include <vector>
#include <utility>
#include <stdexcept>
#include "picosha2.h"

class User {
private:
    const std::string username;
    std::string passwordHash;

public:
    User(std::string user, const std::string& password) :
            username(std::move(user)),
            passwordHash(picosha2::hash256_hex_string(password)) {}

    const std::string& getUsername() const {
        return username;
    }
    const std::string& getPasswordHash() const {
        return passwordHash;
    };

    bool passwordMatches(std::string input) const {
        return picosha2::hash256_hex_string(input) == passwordHash;
    }
};

class Alias {
private:
    const std::string alias;
    const std::string target;

public:
    Alias(std::string alias, std::string target) :
            alias(std::move(alias)),
            target(std::move(target)) {}

    const std::string& getAlias() const {
        return alias;
    }
    const std::string& getTarget() const {
        return target;
    }
};

class Configuration {
private:
    const std::string baseDir;
    const int port;
    const std::vector<User> users;
    const std::vector<Alias> aliases;

    std::pair<bool, std::string> absoluteBase;

public:
    Configuration(std::string baseDir, const int port, std::vector<User> users,
                  std::vector<Alias> aliases) :
            baseDir(std::move(baseDir)), port(port),
            users(std::move(users)), aliases(std::move(aliases)) {
        absoluteBase = std::make_pair(false, "");
    }

    const std::string &getBaseDir() const {
        return baseDir;
    }
    int getPort() const {
        return port;
    }
    const std::vector<User> &getUsers() const {
        return users;
    }
    const std::vector<Alias> &getAliases() const {
        return aliases;
    }

    void initializeAbsolutePath() {
        char* absolutePath = realpath(baseDir.c_str(), nullptr);
        absoluteBase = std::make_pair(true, std::string(absolutePath));
        free(absolutePath);
    }

    const std::string &getAbsoluteBaseDir() const {
        assert(absoluteBase.first);
        return absoluteBase.second;
    }

    static Configuration loadFromString(const std::string&);
};

class ConfigParseError : public std::runtime_error
{
public:
    ConfigParseError(const std::string &message) :
        runtime_error(message) {};
};

#endif //CS527_PROJECT_CONFIG_HPP