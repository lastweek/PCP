#ifndef CS527_PROJECT_SERVER_HPP
#define CS527_PROJECT_SERVER_HPP

#include <utility>
#include <vector>
#include <utility>
#include "config.hpp"
#include "common.hpp"

#define INPUT_BUF_SIZE 1024


class Client {
private:
    const int sock_fd;
    const std::string addr;
    const Configuration& config;

    int timeout = 1000 * 60 * 10; // default timeout of 10 minutes

    std::string inputBuf;

    bool loggedIn = false;
    std::string user = "";

public:
    Client(const int sock_fd, std::string addr, const Configuration& config) :
            sock_fd(sock_fd), addr(std::move(addr)), config(config) {
        lastLoginCmd = std::make_pair(false, "");
    };

    Client(const int sock_fd, std::string addr, const Configuration& config, int timeout):
            Client(sock_fd, std::move(addr), config) {
        lastLoginCmd = std::make_pair(false, "");
        this->timeout = timeout;
    };

    ssize_t _read(char* buf, size_t bytes);
    void _write(const char *buf, size_t bytes);
    void _close();

    void readLoop();
    virtual bool processLine(const std::string&);
    void sendError(const std::string& msg);

    void printMessage(std::string);

    bool isLoggedIn() {
        return loggedIn;
    }

    const std::string& getUsername() const {
        return user;
    }

    void setLoggedIn(std::string username) {
        loggedIn = true;
        user = std::move(username);
    }

    void setLoggedOut() {
        loggedIn = false;
        user = "";
        lastLoginCmd = std::make_pair(false, "");
    }

    const Configuration &getConfig() const {
        return config;
    }

    const std::string& getAddr() const {
        return addr;
    }

    std::pair<bool, std::string> lastLoginCmd;
    PollingStruct ps;
    FileTransfer ft;
};

class Server {
private:
    const Configuration& config;

public:
    explicit Server(const Configuration& config) : config(config) {}

    void start();
    bool terminate = false;
};


using std::vector;

class Command {
private:
    const bool needsLoggedIn;
    const unsigned int nArgs;
public:
    virtual std::string execute(const vector<std::string>& msg, Client* c);
    virtual std::string executeCommand(const vector<std::string>& msg, Client* c) = 0;

    Command(bool needsLoggedIn, unsigned int nArgs) :
            needsLoggedIn(needsLoggedIn), nArgs(nArgs) {};
};

class LoginCommand : public Command {
public:
    LoginCommand() : Command(false, 2) {}

    std::string executeCommand(const vector<std::string>& msg, Client* c) override;
};

class PassCommand : public Command {
public:
    PassCommand() : Command(false, 2) {}

    std::string executeCommand(const vector<std::string>& msg, Client* c) override;
};

class WhoAmICommand : public Command {
public:
    WhoAmICommand() : Command(true, 1) {}

    std::string executeCommand(const vector<std::string>& msg, Client* c) override;
};

class PingCommand : public Command {
public:
    PingCommand() : Command(false, 2) {}

    std::string executeCommand(const vector<std::string>& msg, Client* c) override;
};

class LSCommand : public Command {
public:
    LSCommand() : Command(true, 1) {}

    std::string executeCommand(const vector<std::string>& msg, Client* c) override;
};

class LogoutCommand : public Command {
public:
    LogoutCommand() : Command(true, 1) {}

    std::string executeCommand(const vector<std::string>& msg, Client* c) override;
};

class DateCommand : public Command {
public:
    DateCommand() : Command(true, 1) {}

    std::string executeCommand(const vector<std::string>& msg, Client* c) override;
};

class WCommand : public Command {
public:
    WCommand() : Command(true, 1) {}

    std::string executeCommand(const vector<std::string>& msg, Client* c) override;
};

class CDCommand : public Command {
public:
    CDCommand() : Command(true, 2) {}

    std::string executeCommand(const vector<std::string>& msg, Client* c) override;
};

class GetCommand : public Command {
public:
    GetCommand() : Command(true, 2) {}

    std::string executeCommand(const vector<std::string>& msg, Client* c) override;
};

class PutCommand : public Command {
public:
    PutCommand() : Command(true, 3) {}

    std::string executeCommand(const vector<std::string>& msg, Client* c) override;
};

#endif //CS527_PROJECT_SERVER_HPP
