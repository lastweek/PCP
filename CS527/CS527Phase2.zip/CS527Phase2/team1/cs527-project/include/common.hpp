#ifndef CS527_PROJECT_COMMON_HPP
#define CS527_PROJECT_COMMON_HPP

#include <functional>
#include <vector>
#include <sys/unistd.h>

void trim(std::string &s);
std::vector<std::string> split(const std::string &s, char delim);

std::string exec(const std::string& cmd);

enum PollMode {
    READ,
    WRITE
};

using std::pair;

class PollingStruct {
    std::vector<pair<int, PollMode>> fds;

public:
    int timeout = -1;

    void addDescriptor(int fd, PollMode mode);

    void _poll(
            std::function<void()> onTimeout,
            std::function<void(int)> onReady,
            std::function<void(int)> onError);
};


class FileTransfer {
private:
    int port;

    int fileToGet;
    off_t offset = 0;
    size_t bytesWritten = 0;
    size_t fileSize;

public:
    int serverSocket = -1;
    int getSocket = -1;
    int boundPort = -1;

    FileTransfer() :
            port(0), fileToGet(-1), fileSize(0) {}
    FileTransfer(int file, size_t fileSize) :
            port(0), fileToGet(file), fileSize(fileSize) {}
    FileTransfer(int file, size_t fileSize, int port) :
            port(port), fileToGet(file), fileSize(fileSize) {}

    int setupServerSocket(int& port);
    void onServerConnect(PollingStruct& ps);
    void onWritable();

    void destruct() {
        close(serverSocket);
        close(getSocket);
        close(fileToGet);
    }
};

#endif