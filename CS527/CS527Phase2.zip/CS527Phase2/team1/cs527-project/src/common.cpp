#include <string>
#include <sstream>
#include <vector>
#include <algorithm>
#include <array>
#include <memory>
#include <poll.h>
#include <common.hpp>
#include <cstring>
#include <system_error>
#include <sys/socket.h>
#include <sys/sendfile.h>
#include <netinet/in.h>
#include <iostream>


template<typename Out>
void split(const std::string &s, char delim, Out result) {
    std::stringstream ss(s);
    std::string item;
    while (std::getline(ss, item, delim)) {
        if (item.empty() && delim == ' ') {
            continue;
        }
        *(result++) = item;
    }
}

std::string exec(const std::string& cmd) {
    std::array<char, 128> buffer;
    std::string result;
    std::shared_ptr<FILE> pipe(popen(cmd.c_str(), "r"), pclose);

    std::string msg("=== Running subprocess: " + cmd);
    fprintf(stderr, msg.c_str());

    if (!pipe) throw std::runtime_error("popen() failed!");
    while (!feof(pipe.get())) {
        if (fgets(buffer.data(), 128, pipe.get()) != nullptr)
            result += buffer.data();
    }
    return result;
}

std::vector<std::string> split(const std::string &s, char delim) {
    std::vector<std::string> elems;
    split(s, delim, std::back_inserter(elems));
    return elems;
}

// trim from start (in place)
static inline void ltrim(std::string &s) {
    s.erase(s.begin(), std::find_if(s.begin(), s.end(), [](int ch) {
        return !std::isspace(ch);
    }));
}

// trim from end (in place)
static inline void rtrim(std::string &s) {
    s.erase(std::find_if(s.rbegin(), s.rend(), [](int ch) {
        return !std::isspace(ch);
    }).base(), s.end());
}

// trim from both ends (in place)
void trim(std::string &s) {
    ltrim(s);
    rtrim(s);
}

void PollingStruct::addDescriptor(int fd, PollMode mode) {
    fds.emplace_back(fd, mode);
}

typedef std::function<void(int)> IntFunc;

void PollingStruct::_poll(
        std::function<void()> onTimeout,
        IntFunc onReady, IntFunc onError
) {
    while (true) {
        auto *pollList = new struct pollfd[fds.size()];

        int counter = 0;
        for (const auto &fd : fds) {
            pollList[counter].fd = fd.first;
            if (fd.second == READ) {
                pollList[counter].events = POLLIN | POLLRDHUP;
            } else {
                pollList[counter].events = POLLOUT | POLLRDHUP;
            }

            counter++;
        }

        int pollRes = poll(pollList, fds.size(), timeout);

        if (pollRes < 0) {
            throw std::system_error(errno, std::generic_category(), "poll");
        } else if (pollRes == 0) {
            onTimeout();
            delete[] pollList;
            break;
        }

        for (size_t i = 0; i < fds.size(); i++) {
            if ((pollList[i].revents & POLLHUP) == POLLHUP ||
                    (pollList[i].revents & POLLERR) == POLLERR ||
                    (pollList[i].revents & POLLNVAL) == POLLNVAL ||
                    (pollList[i].revents & POLLRDHUP) == POLLRDHUP) {
                onError(pollList[i].fd);

                fds.erase(fds.begin() + i);
                if (fds.empty()) {
                    delete[] pollList;
                    return;
                }
            }

            if ((pollList[i].revents & POLLIN) == POLLIN ||
                    (pollList[i].revents & POLLOUT) == POLLOUT) {
                onReady(pollList[i].fd);
            }
        }

        delete[] pollList;
    }
}

int FileTransfer::setupServerSocket(int& port) {
    int tempSocket = socket(AF_INET, SOCK_STREAM, 0);

    struct sockaddr_in server;
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(this->port);

    if (bind(tempSocket, (struct sockaddr *) &server, sizeof(server)) < 0) {
        throw std::system_error(errno, std::generic_category(), "bind");
    }

    listen(tempSocket, 1);

    struct sockaddr_in initialized;
    memset(&initialized, 0, sizeof(struct sockaddr_in));

    socklen_t size = sizeof(initialized);
    getsockname(tempSocket, (struct sockaddr *) &initialized, &size);

    port = ntohs(initialized.sin_port);
    boundPort = port;

    serverSocket = tempSocket;
    return tempSocket;
}

void FileTransfer::onServerConnect(PollingStruct& ps) {
    std::cout << "Accepting connection on port " << boundPort << " to allow transfer of file\n";

    struct sockaddr_in client;
    socklen_t sizeOfClient = sizeof(client);
    getSocket = accept4(serverSocket, (struct sockaddr *) &client, &sizeOfClient, SOCK_NONBLOCK);

    if (getSocket < 0) {
        throw std::system_error(errno, std::generic_category(), "accept4");
    }

    ps.addDescriptor(getSocket, WRITE);

    serverSocket = -1;
    close(serverSocket);
}

void FileTransfer::onWritable() {
    ssize_t bytes = sendfile(getSocket, fileToGet, &offset, fileSize - bytesWritten);
    if (bytes <= 0) {
        if (errno == EINTR || errno == EAGAIN) {
            return;
        }
        throw std::system_error(errno, std::generic_category(), "sendfile");
    }
    bytesWritten += bytes;

    if (bytesWritten == fileSize) {
        std::cout << "Done transferring file on port " << boundPort << "\n";
        shutdown(getSocket, 2);
        close(getSocket);

        getSocket = -1;
        bytesWritten = 0;
    }
}