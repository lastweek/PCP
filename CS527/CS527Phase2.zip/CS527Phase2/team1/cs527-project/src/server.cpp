#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <iostream>
#include <system_error>
#include <thread>
#include <unistd.h>
#include <arpa/inet.h>
#include <cstring>
#include <utility>
#include <vector>
#include <common.hpp>
#include <netdb.h>
#include <unordered_map>
#include <mutex>
#include <libgen.h>
#include <fcntl.h>
#include <linux/limits.h>
#include "server.hpp"

void onConnect(int sock_fd, std::string addr, const Configuration& config);

std::mutex usersLock;
std::unordered_map<std::string, int> loggedInUsers;

void Server::start() {
    std::cout << "[i] Starting server on port: " << config.getPort() << "\n";
    std::cout << "    Running from base_dir:   " << config.getBaseDir() << "\n";

    int sock_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (sock_fd == 0) {
        throw std::system_error(errno, std::generic_category(), "open");
    }

    int reuse = 1;
    if (setsockopt(sock_fd, SOL_SOCKET, SO_REUSEADDR, (const char*) &reuse, sizeof(reuse)) < 0) {
        throw std::system_error(errno, std::generic_category(), "setsockopt(SO_REUSEADDR)");
    }

#ifdef SO_REUSEPORT
    if (setsockopt(sock_fd, SOL_SOCKET, SO_REUSEPORT, (const char*) &reuse, sizeof(reuse)) < 0) {
        throw std::system_error(errno, std::generic_category(), "setsockopt(SO_REUSEPORT) failed");
    }
#endif

    struct sockaddr_in server;
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(static_cast<uint16_t>(config.getPort()));

    if (bind(sock_fd, (struct sockaddr *) &server, sizeof(server)) < 0) {
        throw std::system_error(errno, std::generic_category(), "bind");
    }

    listen(sock_fd, 16);

    std::cout << "[x] Socket bound and listening" << "\n";

    int client_fd;
    struct sockaddr_in client;

    socklen_t sizeOfClient = sizeof(client);
    while ((client_fd = accept(sock_fd, (struct sockaddr *) &client, &sizeOfClient)))
    {
        std::string clientAddr = inet_ntoa(client.sin_addr);
        std::cout << "  [-] Accepting connection from " << clientAddr << "\n";

        std::thread clientThread(onConnect, client_fd, clientAddr, config);
        clientThread.detach();

        if (terminate) {
            break;
        }
    }

    if (client_fd < 0) {
        throw std::system_error(errno, std::generic_category(), "accept");
    }
}

void onConnect(int sock_fd, std::string addr, const Configuration& config) {
    chdir(config.getBaseDir().c_str());

    Client client = Client(sock_fd, std::move(addr), config);
    client.readLoop();
}


void Client::readLoop() {
    ps.addDescriptor(sock_fd, READ);

    auto onTimeout = [this]() {
        printMessage("Connection timed out");
        _close();
    };
    auto onError = [this](int fd) {
        if (fd == sock_fd) {
            _close();
            throw std::runtime_error("Socket disconnected");
        }
    };
    auto onRead = [this](int fd) {
        if (fd == ft.serverSocket) {
            ft.onServerConnect(ps);
            return;
        }
        if (fd == ft.getSocket) {
            ft.onWritable();
            return;
        }

        char buf[1024];
        auto read = (size_t) _read(buf, 1024);

        inputBuf += std::string(buf, read);

        size_t newLineIdx = inputBuf.find_first_of('\n');
        if (inputBuf.size() > 1024 && newLineIdx == std::string::npos) {
            sendError("Line sent was too long.");
            _close();
            throw std::runtime_error("Disconnecting. Client line too long");
        }

        while ((newLineIdx = inputBuf.find_first_of('\n')) != std::string::npos) {
            if (processLine(inputBuf.substr(0, newLineIdx))) {
                throw std::runtime_error("Exit by processLine");
            }

            if (newLineIdx + 1 == inputBuf.size()) {
                inputBuf = "";
            } else {
                inputBuf = inputBuf.substr(newLineIdx + 1, std::string::npos);
            }
        }
    };

    try {
        ps.timeout = timeout;
        ps._poll(onTimeout, onRead, onError);
    } catch (const std::runtime_error& e) {
        printMessage("[!] " + std::string(e.what()));
    }

    _close();
}

bool Client::processLine(const std::string& line) {
    printMessage("Received line: " + line);

    if (line == "exit") {
        _close();
        return true;
    }
    std::vector<std::string> tokens = split(line, ' ');
    if (tokens.empty()) {
        return false;
    }

    std::string response;

    if (tokens[0] == "login") {
        response = LoginCommand().execute(tokens, this);
    } else if (tokens[0] == "pass") {
        response = PassCommand().execute(tokens, this);
    } else if (tokens[0] == "ping") {
        response = PingCommand().execute(tokens, this);
    } else if (tokens[0] == "ls") {
        response = LSCommand().execute(tokens, this);
    } else if (tokens[0] == "cd") {
        response = CDCommand().execute(tokens, this);
    } else if (tokens[0] == "get") {
        response = GetCommand().execute(tokens, this);
    } else if (tokens[0] == "put") {
        response = PutCommand().execute(tokens, this);
    } else if (tokens[0] == "whoami") {
        response = WhoAmICommand().executeCommand(tokens, this);
    } else if (tokens[0] == "date") {
        response = DateCommand().executeCommand(tokens, this);
    } else if (tokens[0] == "w") {
        response = WCommand().executeCommand(tokens, this);
    } else if (tokens[0] == "logout") {
        response = LogoutCommand().executeCommand(tokens, this);
    } else {
        auto idx = config.getAliases().end();

        for (size_t i = 0; i < config.getAliases().size(); i++) {
            if (config.getAliases()[i].getAlias() == tokens[0]) {
                idx = config.getAliases().begin() + i;
                break;
            }
        }

        if (idx == config.getAliases().end()) {
            response = "ERROR command `" + line + "` not found\n";
        } else {
            auto command = (*idx).getTarget();
            response = exec(command);
        }
    }

    if (!response.empty()) {
        printMessage("[response] " + response);
        _write(response.c_str(), response.size());
    }

    // mark the last command as not being login
    if (tokens[0] != "login") {
        lastLoginCmd = std::make_pair(false, "");
    }

    return false;
}

void Client::printMessage(std::string msg) {
    size_t len = strlen(msg.c_str());
    char localLine[len + 1];
    localLine[len] = '\0';
    memcpy(localLine, msg.c_str(), msg.size());

    if (len == 0) {
        return;
    }
    fprintf(stderr, " [%s] %s\n", addr.c_str(), localLine);
}

void Client::sendError(const std::string& msg) {
    std::string error = "ERROR " + msg + "\n";
    _write(error.c_str(), error.size());
}

void Client::_close() {
    if (isLoggedIn()) {
        usersLock.lock();
        loggedInUsers[getUsername()]--;

        if (loggedInUsers[getUsername()] == 0) {
            loggedInUsers.erase(getUsername());
        }

        usersLock.unlock();
    }

    // clear out any file transfers
    ft.destruct();
    close(sock_fd);
}

void Client::_write(const char *buf, size_t bytes) {
    if (write(sock_fd, buf, bytes) == -1) {
        //throw std::system_error(errno, std::generic_category(), "write");
    }
}

ssize_t Client::_read(char *buf, size_t bytes) {
    ssize_t bytesRead = read(sock_fd, buf, bytes);
    if (bytesRead == -1) {
        //throw std::system_error(errno, std::generic_category(), "read");
    }
    return bytesRead;
}

// ====================================
// Commands
// ====================================

using std::vector;

std::string Command::execute(const vector<std::string>& msg, Client* c) {
    if (this->needsLoggedIn && !c->isLoggedIn()) {
        return "ERROR You must be logged in to perform that command\n";
    }

    if (msg.size() != nArgs) {
        return "ERROR Incorrect number of args, this command takes " + std::to_string(nArgs) + " arguments\n";
    }

    return executeCommand(msg, c);
}

std::string LoginCommand::executeCommand(const vector<std::string> &msg, Client *c) {
    const User* user = nullptr;

    if (c->isLoggedIn()) {
        return "ERROR Already logged in\n";
    }

    for (const User& u : c->getConfig().getUsers()) {
        if (u.getUsername() == msg[1]) {
            user = &u;
            break;
        }
    }

    if (user == nullptr) {
        return "ERROR Invalid username\n";
    }

    c->lastLoginCmd = std::make_pair(true, user->getUsername());
    return "";
}

std::string PassCommand::executeCommand(const vector<std::string> &msg, Client *c) {
    if (!c->lastLoginCmd.first) {
        return "ERROR pass command must follow immediately after a login command\n";
    }

    const User* user = nullptr;

    for (const User& u : c->getConfig().getUsers()) {
        if (u.getUsername() == c->lastLoginCmd.second) {
            user = &u;
            break;
        }
    }

    if (user == nullptr) {
        return "ERROR ????\n";
    }
    if (!user->passwordMatches(msg[1])) {
        return "ERROR Invalid password\n";
    }

    c->setLoggedIn(user->getUsername());
    c->printMessage("Successfully logged in as: " + user->getUsername());

    usersLock.lock();
    loggedInUsers[user->getUsername()]++;
    usersLock.unlock();

    return "";
}

std::string WCommand::executeCommand(const vector<std::string>&, Client *) {
    std::string response;

    if (loggedInUsers.empty()) {
        return "\n";
    }

    for (const auto& pair : loggedInUsers) {
        response += pair.first;
        response += " ";
    }

    response.resize(response.size() - 1);
    response += "\n";
    return response;
}

std::string WhoAmICommand::executeCommand(const vector<std::string>&, Client *c) {
    return c->getUsername() + "\n";
}

std::string LSCommand::executeCommand(const vector<std::string>&, Client*) {
    return exec("ls -l");
}

std::string CDCommand::executeCommand(const vector<std::string> &msg, Client *c) {
    char path[128];

    static char current[PATH_MAX];
    char* dir = get_current_dir_name();

    strcpy(current, dir);
    strcat(current, "/");
    strcat(current, msg[1].c_str());

    char* real_path = realpath(current, nullptr);
    if (real_path == nullptr) {
        return "ERROR Directory not found\n";
    }

    // check size limitations
    size_t len = strlen(current);
    strncpy(path, current, len);
    path[128] = '\0';
    if (strlen(path) > 100) {
        return "ERROR path too long";
    }

    const char* base = c->getConfig().getAbsoluteBaseDir().c_str();

    if (strncmp(real_path, base, strlen(base)) == 0) {
        chdir(real_path);
        free(real_path);
        return "";
    } else {
        free(real_path);
        // path traversal
        return "ERROR Directory not found\n";
    }
}

std::string GetCommand::executeCommand(const vector<std::string> &msg, Client *c) {
    char* _cwd = get_current_dir_name();
    std::string cwd(_cwd);
    free(_cwd);

    std::string path = cwd + "/" + msg[1];

    char* real_path = realpath(path.c_str(), nullptr);
    if (real_path == nullptr) {
        return "ERROR File not found\n";
    }

    std::string baseDir = dirname(real_path);
    free(real_path);

    if (baseDir != cwd) {
        return "ERROR File must be in current working directory\n";
    }

    int fileToGet = open(path.c_str(), O_RDONLY);
    if (fileToGet < 0) {
        std::string err(strerror(errno));
        c->printMessage("Unable to open file: " + err);
        return "ERROR open() " + err + "\n";
    }

    c->ft.destruct();

    struct stat s;
    memset(&s, 0, sizeof(struct stat));
    stat(path.c_str(), &s);

    c->ft = FileTransfer(fileToGet, s.st_size);

    int port;
    int serverSocket = c->ft.setupServerSocket(port);
    c->ps.addDescriptor(serverSocket, READ);

    return "get port: " + std::to_string(port) + " size: " + std::to_string(s.st_size) + "\n";
}

#define MAX_PORT 65535
#define MIN_PORT 49152

std::string PutCommand::executeCommand(const vector<std::string> &msg, Client *c) {
    if (msg[1].find('/') != std::string::npos) {
        return "ERROR uploaded filename may not have slashes\n";
    }
    if (msg[1].find('\'') != std::string::npos || msg[1].find(';') != std::string::npos) {
        return "ERROR no funny business\n";
    }
    try {
        int size = stoi(msg[2]);
        if (size > 1024 * 1024 * 1024) {
            return "ERROR too big\n";
        }
    } catch (const std::invalid_argument&) {
        return "ERROR size must be int\n";
    }

    std::random_device r;
    std::default_random_engine e1(r());
    std::uniform_int_distribution<int> uniform_dist(MIN_PORT, MAX_PORT);
    int randPort = uniform_dist(e1);

    std::string cmd("sleep 1; nc " + c->getAddr() + " " + std::to_string(randPort) + " > " + msg[1]);

    std::thread([cmd]{
        exec(cmd);
    }).detach();

    return "put port: " + std::to_string(randPort) + "\n";
}

std::string DateCommand::executeCommand(const vector<std::string>&, Client *) {
    return exec("date");
}

std::string PingCommand::executeCommand(const vector<std::string> &msg, Client* c) {
    struct addrinfo hints;
    memset(&hints, 0, sizeof(addrinfo));
    hints.ai_family = AF_INET;

    struct addrinfo* info_ptr;

    int result = getaddrinfo(msg[1].c_str(), nullptr, &hints, &info_ptr);
    if (result) {
        std::string errMsg(gai_strerror(result));
        c->printMessage("getaddrinfo: " + errMsg);
        return "ERROR Invalid host\n";
    }

    if (info_ptr == nullptr) {
        return "ERROR Invalid host\n";
    }

    freeaddrinfo(info_ptr);

    return exec("ping " + msg[1] + " -c 1");
}

std::string LogoutCommand::executeCommand(const vector<std::string>&, Client *c) {
    c->setLoggedOut();
    return "";
}