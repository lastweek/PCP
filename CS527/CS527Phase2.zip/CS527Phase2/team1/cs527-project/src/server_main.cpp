#include <string>
#include <fstream>
#include <system_error>
#include <iostream>
#include <sys/stat.h>
#include <climits>
#include <csignal>
#include "config.hpp"
#include "server.hpp"

std::string get_file_contents(const std::string& filename)
{
    std::ifstream in(filename, std::ios::in | std::ios::binary);
    if (in)
    {
        std::string contents;
        in.seekg(0, std::ios::end);
        contents.resize(in.tellg());
        in.seekg(0, std::ios::beg);
        in.read(&contents[0], contents.size());
        in.close();
        return(contents);
    }
    throw std::system_error(errno, std::generic_category(), "open(" + filename + ")");
}

int main() {
    try {
        signal(SIGPIPE, SIG_IGN);

        std::string configFile = get_file_contents("sploit.conf");

        Configuration config = Configuration::loadFromString(configFile);

        if (config.getPort() < 1 || config.getPort() > USHRT_MAX) {
            throw ConfigParseError("port must be between 1 and " + std::to_string(USHRT_MAX));
        }

        struct stat info;
        if (stat(config.getBaseDir().c_str(), &info) != 0) {
            throw std::system_error(errno, std::generic_category(),
                                    "stat(" + config.getBaseDir() + ")");
        } else if (!S_ISDIR(info.st_mode)) {
            throw std::system_error(ENOTDIR, std::generic_category(),
                                    "base directory not a directory");
        }
        config.initializeAbsolutePath();

        Server server(config);
        server.start();
    } catch (const std::system_error& e) {
        std::cerr << e.what() << "\n";
        return ENOENT;
    } catch (const ConfigParseError& e) {
        std::cerr << "ConfigParseError: " << e.what() << "\n";
        return EBADMSG;
    }

    return 0;
}