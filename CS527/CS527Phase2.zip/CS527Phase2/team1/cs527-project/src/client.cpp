#include <iostream>
#include <netdb.h>
#include <cstring>
#include <stdexcept>
#include <system_error>
#include <unistd.h>
#include <fstream>
#include <fcntl.h>
#include <sys/stat.h>
#include "common.hpp"

struct sockaddr_in resolveHost(char* host, char* port) {
    struct sockaddr_in serverAddr;
    memset(&serverAddr, 0, sizeof(sockaddr_in));

    // resolve the ip address of the server
    struct addrinfo hints;
    memset(&hints, 0, sizeof(addrinfo));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;

    struct addrinfo* info_ptr;

    int result = getaddrinfo(host, nullptr, &hints, &info_ptr);
    if (result) {
        std::string errorMsg(gai_strerror(result));
        throw std::runtime_error("getaddrinfo: " + errorMsg);
    }

    if (info_ptr == nullptr) {
        return serverAddr;
    }

    serverAddr.sin_addr = ((sockaddr_in*) (info_ptr->ai_addr))->sin_addr;
    serverAddr.sin_family = AF_INET;
    try {

        serverAddr.sin_port = htons(static_cast<uint16_t>(std::stoi(port)));
    } catch (const std::invalid_argument&) {
        throw std::runtime_error("port must be a number");
    }

    freeaddrinfo(info_ptr);

    return serverAddr;
}

std::string host("");

PollingStruct ps;

FileTransfer ft;
int fileToTransfer = -1;
int fSize = -1;

std::string fileToGet("");

std::string inputBuf;

std::string onCommandInput(const std::string& s) {
    auto tokens = split(s, ' ');
    if (tokens.empty()) {
        return s;
    }

    if (tokens.size() == 2 && tokens[0] == "get") {
        fileToGet = tokens[1];
    } else if ((tokens.size() == 2 || tokens.size() == 3) && tokens[0] == "put") {
        ft.destruct();

        fileToTransfer = open(tokens[1].c_str(), O_RDONLY);
        if (fileToTransfer < 0) {
            perror("open()");
            return s;
        }

        // if no file size provided
        if (tokens.size() == 2) {
            struct stat fileStat;
            stat(tokens[1].c_str(), &fileStat);

            char *fileName = strndup(tokens[1].c_str(), tokens[1].size());
            char *_base = basename(fileName);
            std::string base(_base);
            free(fileName);

            fSize = fileStat.st_size;
            return s + " " + std::to_string(fSize);
        } else {
            try {
                fSize = std::stoi(tokens[2]);
                if (fSize < 0 ) {
                    throw std::runtime_error("File size must be positive");
                }
            } catch (const std::invalid_argument&) {
                throw std::runtime_error("File size must be an integer");
            }
            return s;
        }

    }

    return s;
}

void onCommandReceive(const std::string& s) {
    auto tokens = split(s, ' ');
    if (tokens.empty()) {
        return;
    }

    if (tokens.size() == 5 && tokens[0] == "get" && tokens[1] == "port:" && tokens[3] == "size:") {
        if (fileToGet.empty()) {
            throw std::runtime_error("Attempting to transfer file before get call");
        }
        int port;
        try {
            port = std::stoi(tokens[2]);
        } catch (const std::invalid_argument&) {
            throw std::runtime_error("Non integer port in get");
        }

        std::string command("nc " + host + " " + std::to_string(port) + " > " + fileToGet);

        system(command.c_str());
        fileToGet = "";

    } else if (tokens.size() == 3 && tokens[0] == "put" && tokens[1] == "port:") {
        if (fileToTransfer == -1) {
            throw std::runtime_error("Attempting to transfer file before put call");
        }

        try {
            int port = std::stoi(tokens[2]);
            ft = FileTransfer(fileToTransfer, fSize, port);
            int serverSocket = ft.setupServerSocket(port);
            ps.addDescriptor(serverSocket, READ);

            std::cerr << "> Listening on port " << port << " for file transfer\n";
        } catch (const std::invalid_argument&) {
            throw std::runtime_error("Non integer port in put");
        }
    }
}

void handleNewLines() {
    unsigned long newLineIdx;

    while ((newLineIdx = inputBuf.find_first_of('\n')) != std::string::npos) {
        onCommandReceive(inputBuf.substr(0, newLineIdx));

        if (newLineIdx + 1 == inputBuf.size()) {
            inputBuf = "";
        } else {
            inputBuf = inputBuf.substr(newLineIdx + 1, std::string::npos);
        }
    }

    if (inputBuf.size() > 1024 * 10) {
        inputBuf = "";
    }
}

void readLoop(int sock) {
    ps.addDescriptor(STDIN_FILENO, READ);
    ps.addDescriptor(sock, READ);

    auto onError = [sock](int fd){
        if (fd == sock) {
            throw std::runtime_error("[!] Disconnected from server");
        }
    };
    auto onRead = [sock](int fd) {
        if (fd == ft.serverSocket) {
            ft.onServerConnect(ps);
        } else if (fd == ft.getSocket) {
            ft.onWritable();
        } else if (fd == STDIN_FILENO) {
            std::string input;
            std::getline(std::cin, input);

            input = onCommandInput(input);

            input += "\n";

            write(sock, input.c_str(), input.size());
        } else {
            char buf[1024];

            ssize_t bytes = read(fd, &buf, 1024);
            write(STDOUT_FILENO, buf, bytes);

            inputBuf += std::string(buf, bytes);
            handleNewLines();
        }
    };
    auto onTimeout = []{};
    ps._poll(onTimeout, onRead, onError);
}

void readToFromFile(int sock, const std::string& in, const std::string& out) {
    std::ifstream infile(in);
    int outfile = open(out.c_str(), O_CREAT | O_RDWR | O_TRUNC, 0666);

    std::string line;
    while (std::getline(infile, line)) {
        line = onCommandInput(line);

        write(sock, line.c_str(), line.size());
        write(sock, "\n", 1);
        std::cerr << "Sending command: " << line << "\n";
    }

    ps.addDescriptor(sock, READ);

    auto onError = [sock](int fd) {
        if (fd == sock) {
            throw std::system_error(errno, std::generic_category(),
                                    "Unexpectedly disconnected from server");
        }
    };
    auto onTimeout = []{};
    auto onRead = [outfile](int fd) {
        if (fd == ft.serverSocket) {
            ft.onServerConnect(ps);
            return;
        } else if (fd == ft.getSocket) {
            ft.onWritable();
            return;
        }

        char buf[1024];
        ssize_t bytes = read(fd, &buf, 1024);
        write(outfile, &buf, bytes);

        inputBuf += std::string(buf, bytes);
        handleNewLines();
    };

    ps.timeout = 2000;
    ps._poll(onTimeout, onRead, onError);

    close(outfile);
    close(sock);
}

int main(int argc, char ** argv) {
    if (argc != 5 && argc != 3) {
        std::cerr << "Usage: ./client SERVER_IP SERVER_PORT\n";
        std::cerr << "       ./client SERVER_IP SERVER_PORT IN_FILE OUT_FILE\n";
        return -2;
    }

    try {
        host = argv[1];

        struct sockaddr_in server = resolveHost(argv[1], argv[2]);

        std::cerr << "[i] Connecting to " << argv[1] << ":" << argv[2] << "\n";

        int sock = socket(AF_INET , SOCK_STREAM , 0);
        if (sock < 0) {
            throw std::system_error(errno, std::generic_category(), "socket");
        }

        if (connect(sock, (struct sockaddr *) &server, sizeof(struct sockaddr_in)) < 0) {
            throw std::system_error(errno, std::generic_category(), "connect");
        }

        if (argc == 3) {
            readLoop(sock);
        } else {
            readToFromFile(sock, argv[3], argv[4]);
        }
    } catch (const std::runtime_error& e) {
        std::cerr << e.what() << "\n";
        return -1;
    }
}
