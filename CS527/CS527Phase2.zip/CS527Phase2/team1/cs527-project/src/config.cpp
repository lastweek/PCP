#include <iostream>
#include <vector>
#include <algorithm>

#include "common.hpp"
#include "config.hpp"

Configuration Configuration::loadFromString(const std::string& str) {
    std::pair<bool, std::string> baseDir = std::make_pair(false, "");
    std::pair<bool, int> port = std::make_pair(false, 0);
    std::vector<User> users;
    std::vector<Alias> aliases;

    std::vector<std::string> lines = split(str, '\n');

    for (std::string line : lines) {
        trim(line);
        // skip empty lines and lines with comments
        if (line.empty() || line[0] == '#') {
            continue;
        }

        std::vector<std::string> tokens = split(line, ' ');

        if (tokens[0] == "base") {
            if (tokens.size() != 2) throw ConfigParseError("base requires one argument");

            baseDir = std::make_pair(true, tokens[1]);
        } else if (tokens[0] == "port") {
            if (tokens.size() != 2) throw ConfigParseError("port requires one argument");

            int parsedPort;
            try {
                parsedPort = std::stoi(tokens[1]);
            } catch (const std::exception&) {
                throw ConfigParseError("port must be an integer");
            }

            port = std::make_pair(true, parsedPort);
        } else if (tokens[0] == "user") {
            if (tokens.size() != 3) throw ConfigParseError("user requires two arguments");

            users.emplace_back(tokens[1], tokens[2]);
        } else if (tokens[0] == "alias") {
            if (tokens.size() <= 2) throw ConfigParseError("alias requires at least two arguments");

            // get everything from the second space to the end of the line
            size_t firstSpacePos = line.find(' ') + 1;
            std::string target = line.substr(line.find(' ', firstSpacePos) + 1, std::string::npos);
            aliases.emplace_back(tokens[1], target);
        } else {
            throw ConfigParseError("Unknown configuration directive: " + tokens[0]);
        }
    }

    if (!baseDir.first) {
        throw ConfigParseError("Base dir not specified");
    }
    if (!port.first) {
        throw ConfigParseError("Port not specified");
    }

    return Configuration(baseDir.second, port.second, users, aliases);
}