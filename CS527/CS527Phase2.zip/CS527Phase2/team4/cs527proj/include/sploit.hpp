#ifndef SPLOIT_HPP
#define SPLOIT_HPP

#include "Commands.hpp"

#define PROPERTIES  "sploit.conf"

#endif
