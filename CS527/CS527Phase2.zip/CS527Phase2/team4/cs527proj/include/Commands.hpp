#ifndef COMMANDS_HPP
#define COMMANDS_HPP
#include "Networking.hpp"

namespace cm {
    class Command {
        protected:
            Session& _session;
        public:
            virtual void execute(void) = 0;
            Command(Session& session) : 
                _session(session) {}
            virtual ~Command(void);
            Session& getSession(void) { return _session; }

            /* Executes the shell command */
            std::string shell(std::string&);
    };

    class AuthCommand : public Command {
        public:
            AuthCommand(Session&);
    };

    class UnauthCommand : public Command {
        public:
            UnauthCommand(Session& s);
    };

    class StateChangeCommand : public Command {
        public:
            StateChangeCommand(Session& s);
    };

    class LoginCommand : public StateChangeCommand {
        protected:
            std::string _username;
        public:
            LoginCommand(Session& s, std::string& username);
            virtual void execute(void) override;
    };

    class PassCommand : public StateChangeCommand {
        protected:
            std::string _password;
        public:
            PassCommand(Session&, std::string&);
            virtual void execute(void) override;
    };

    class PingCommand : public UnauthCommand {
        protected:
            std::string _host;
            std::string _pingcmd;
        public:
            PingCommand(Session& s, std::string& host);
            virtual void execute(void) override;
    };

    class LSCommand : public AuthCommand {
        public:
            LSCommand(Session& s) : AuthCommand(s) {}
            virtual void execute(void) override;
    };
    
    class CDCommand : public AuthCommand {
        protected:
            std::string _newDir;
        public:
            CDCommand(Session& s, std::string& newDir);
            virtual void execute(void) override;
    };

    class GetCommand : public AuthCommand {
        protected:
            std::string _filename;
        public:
            GetCommand(Session& s, std::string& filename);
            virtual void execute(void) override;
    };

    class PutCommand : public AuthCommand {
        protected:
            std::string _filename;
            std::uintmax_t _size;
        public:
            PutCommand(Session &s, std::string& filename, std::uintmax_t size);
            virtual void execute(void) override;
    };

    class DateCommand : public AuthCommand {
        public:
            DateCommand(Session& s) : 
                AuthCommand(s) {}
            virtual void execute(void) override;
    };

    class WhoAmICommand : public AuthCommand {
        public:
            WhoAmICommand(Session& s) :
                AuthCommand(s) {}
            virtual void execute(void) override;
    };

    class WCommand : public AuthCommand {
        public:
            WCommand(Session& s) :
                AuthCommand(s) {}
            virtual void execute(void) override;
    };

    class LogoutCommand : public StateChangeCommand {
        public:
            LogoutCommand(Session& s);
            virtual void execute(void) override;
    };

    class MiscCommand : public AuthCommand {
        protected:
            std::string _cmd;
            void trim_leading(std::string&);
        public:
            MiscCommand(Session& s, std::string& cmd);
            virtual void execute(void) override;
    };
}
#endif
