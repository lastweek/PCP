#include <stdexcept>
#include <string>

namespace cm {
	class CommandException : public std::runtime_error {
		public:
			CommandException(const char*);
	};

	/* For when an unauthorized user tries to execute
	 * a command requiring authorization
	 */
	class UnauthorizedException : public CommandException {
		public:
			UnauthorizedException(const char*);
	};

	/* User attempts login when already logged in */
	class UserAuthException : public CommandException {
		public:
			UserAuthException(const char*);
	};

	/* User is not listed in the configuration file */
	class InvalidUserException : public CommandException {
		public:
			InvalidUserException(const char*);
	};

	/* File or directory does not exist */
	class FileNotFoundException : public CommandException {
		public:
			FileNotFoundException(const char*);
	};

	/* File is not a directory */
	class FileNotDirectoryException : public CommandException {
		public:
			FileNotDirectoryException(const char*);
	};

	/* File is a directory */
	class FileIsDirectoryException : public CommandException {
		public:
			FileIsDirectoryException(const char*);
	};

    class InvalidHostException : public CommandException {
        public:
            InvalidHostException(const char*);
    };

    class InvalidFileNameException : public CommandException {
        public:
            InvalidFileNameException(const char*);
    };
    class InvalidFileSizeException : public CommandException {
        public:
            InvalidFileSizeException(const char*);
    };

    class EmptyCommandException : public CommandException {
        public:
            EmptyCommandException(const char*);
    };
}
