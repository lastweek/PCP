#ifndef SPLOIT_HPP
#define SPLOIT_HPP

#ifdef DEBUG
#define debug(x) fprintf(stderr, x)
#else
#define debug(x) ;
#endif

#endif