#ifndef SOCKET_HPP_
#define SOCKET_HPP_

#include <arpa/inet.h>
#include <netinet/in.h>
#include <string>
#include <sys/socket.h>
#include <sys/types.h>
#include <fstream>

/* 
*   Wrapper on c TCP sockets. The standard usage of client and server sockets
*   looks like this:
*   
*       Server                                          Client
*       ------                                          ------
*   Socket srvSocket;                               Socket socket;
*   Socket cliSocket;                                      |
*          |                                               |
*   srvSocket.bind(port);                                  |
*          |                                               |
*   srvSocket.listen(nrequests);                           |
*          |                                               |
*   srvSocket.accept(cliSocket);                           |
*          |<---------------------------------------socket.connect(host, port);
*          |                                               |
*   cliSocket.{send(),recv()};<-------------------->socket.{send(),recv()}; 
*/

namespace cm {
    
    class Socket {
    public:
        /* default socket buffer size */
        static int DFLTBUFFSIZE; 
        /* get global name for host machine */
        static std::string gethostname(void);
        /* Default Constructor */
        Socket();
        /* Construct socket with buffer of size buffSize bytes */
        Socket(int buffSize);
        /* Bind to port (server) */
        void bind(int port);
        /* Listen for up to nrequests simultaneous requests (server) */
        void listen(int nrequests);
        /* Accept incoming connection request and set up client socket to handle it
            (server) (blocks if listen queue is empty) */
        void accept(Socket& clientSocket);
        /* Connect server on to given host, port (client) */
        void connect(const char* hostname, short port);
        /* Get message from socket peer (blocking) */
        std::string& recv(void);
        /* Send message to socket peer */
        void send(std::string message) const;
        /* Getters */
        int getLocalPort(void);
        int getRemotePort(void);
        std::string getLocalIP(void);
        std::string getRemoteIP(void);
        int getBuffSize(void);
        /* read exactly n bytes into file stream */
        void recvFile(std::fstream& file, int nbytes);
        /* Destructor */
        ~Socket(void);
        /* Returns true if there is data ready for reading */
        bool data_avail(void);
    protected:
        int _sock_fd;                       /* socket file descriptor           */
        struct sockaddr_in _local_addr;     /* local host/port info             */
        struct sockaddr_in _remote_addr;    /* remote host/port info            */
    private:
        char* _msgBuffer;   /* message buffer                   */
        int _buffSize;      /* size of message buffer (bytes)   */
        std::string _message;
        /* Receive message of given length into given buffer (blocking) */
        int _recv(char* buffer, int length); 
        /* Send message of given length in given buffer */
        void _send(char* buffer, int length) const; 
        /* check c errno and generate exception */
        static void _error(const char* msg);
    };

    /* Stream socket input to string */
    void operator>>(Socket& socket, std::string& str);
    /* Stream string to output socket */
    void operator<<(const Socket& socket, const std::string& str);
    /* Stream socket to fstream */
    void operator<<(std::fstream& fs, Socket& socket);
    /* Stream fstream to socket */
    void operator<<(Socket& socket, std::fstream& fs);

} /* namespace cm */

#endif /* SOCKET_HPP_ */
