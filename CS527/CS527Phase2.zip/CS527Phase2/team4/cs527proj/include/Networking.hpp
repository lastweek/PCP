#ifndef NETWORKING_HPP_
#define NETWORKING_HPP_
#pragma GCC diagnostic ignored "-Wformat-security"
#include <cstdint>
#include <iostream>
#include <regex>
#include <string>
#include <set>
#include <map>
#include <sstream>
#include <vector>
#include <experimental/filesystem>
#include <map>
#include <fstream>
#include <thread>
#include <mutex>
#include "Socket.hpp"
#include "debug.hpp"

namespace fs = std::experimental::filesystem;

namespace cm {
    class Session;
    class Command;

    /* Represents the information contained in the 
     * configuration file
     */
    class Configuration {
        protected:
            /* Stores the user names and passwords from sploit.conf. */
            std::map<std::string, std::string> _userPw;
            /* Store the base from sploit.conf. */
            fs::path _base;
            /* Store port from sploit.conf. */
            int _port;
            /* Store aliases */
            std::map<std::string, std::string> _alias;
            /* Store sploit file. */
            std::string _sploitFile;
            void parseSploit(void);
        public:
            /* Constructor that takes in the file with path of sploit.conf.
            */
            Configuration(std::string& sploitFile);
            /* Returns true if the supplied password is the correct
             * password for username. False otherwise.
             */
            bool testPassword(std::string& username, std::string& password);
            /* Returns true if the username is listed as a user
             * in the configuration file. False otherwise.
             */
            bool isValidUser(std::string& username);

            /* Returns the port on which the server should listen for clients */
            int getServerPort(void);

            /* Parses the sploit.conf file and store resluts in
             * data members.
             */
            void parseSploit(std::string& sploitFile);
            /* Get the port */
            int getPort(void);
            /* Get the base */
            fs::path& getBase(void);
            /* Return the alias command string
             * Returns null if there is no alias
             */
            std::string getAliasCmd(std::string& alias);
    };
    /* Client class */
    class Client {
        public:
            /* Get the next command from the user or vector
             * Return 0 on success and 1 if no command is found.
             */
            bool getNextCommand(std::string& nextCmd);
            void setData(std::string& sIP, int sPort, std::string& in, std::string& out);
            void setData(std::string& sIP, int sPort);
            void start(void);
            Client();
       	    void sendLogoutOnSig(); 
        private:
            /* User or automated mode, 0 and 1 respectively */
            int _mode;
            /* User input when starting the client */
            std::string _serverIP;
            int _serverPort;
            std::string _inFile;
            std::string _outFile;
        
            /* In automated mode set a vector of commands read in from infile */
            std::vector<std::string> _cmdVec;
            /* Socekt to sent commands */
            cm::Socket clientSocket;
            std::thread puttd;
            std::thread gettd;
            void putCMD(int port, int filesize, std::string& filePath);
            void getCMD(int port, int filesize, std::string& filePath);
        
    };
    
    /* Represents the current state of the server */
    class Server {
        public:
            /* Return a list of users currently connected */
            std::set<std::string> getConnectedUsers(void);
            Configuration& getConfig(void);
            Server(Configuration config);

            /* Creates a new session */ 
            Session& startSession(std::string& username);
            /* Removes the user from the connected users list
             * (if the user is authenticated), and deletes the 
             * session
             */
            void endSession(Session& s);

            /* Returns command object */
            Command& getCommandObj(Session& s, std::string& cmd);

            /* Begin accepting and dispatching client connections */
            void start(void);

            /* Signal handler for quitting, closes all clients, and
             * frees all objects, and quits gracefully
             */
            void end(void);

        private:
            /* information from configuration file */
            Configuration _configuration;
            /* main socket for accepting new connections */
            Socket _mainSocket;
            /* track running sessions */
            std::set<std::shared_ptr<Session>> _sessions;
            /* Add session to session table */
            void _addSession(std::shared_ptr<Session> sptr);
            /* Clean any completed sessions */
            void _cleanSessions(void); 
    };

    /* Represents a session file transfter */
    class FileTransfer {
        private:
            std::thread _thread;            /* file transfer thread */
            cm::Socket _ctSocket;           /* connection socket */
            cm::Socket _ftSocket;           /* file transfer socket */
            Session&    _session;           /* Session that owns file transfer */
            std::fstream _file;             /* File being transfered */
            bool _finished;                 /* File transfer complete */
            std::unique_ptr<char[]> _path;  /* Path to file */
            FileTransfer();         /* can't create without session reference */
            /* internal thread function for reading incoming file */
            void _read(std::uintmax_t size);
            /* internal thread function for writing outgoing file */
            void _write(void);
            /* internal thread function for ending file transfer */
            void _endTransfer(void);
        public:
            FileTransfer(Session& session);
            /* set file name */
            void setPath(fs::path& path);
            /* get local port for file transfer */
            int getPort(void);
            /* get handle to file transfer thread */
            std::thread& getThread(void);
            /* read up to size bytes of file from client into given file path */
            void read(fs::path& path, std::uintmax_t size);
            /* write file to client */
            void write(fs::path& path);
            /* see if file transfer is complete */
            bool isFinished(void);
    };

    /* Represents one single client connected to the server */
    class Session {
        protected:
            std::string _username;  /* user name for this session */
            bool _auth;             /* whether client is authenticated yet */
            void checkValidUser(void);
            bool _run;              /* flag to keep running thread or stop it */
            cm::Server& _server;    /* server that owns this session */
            cm::Socket _socket;     /* socket connection to client */
            std::thread _thread;    /* server side thread running this session */
            fs::path _currentDir;   /* current session directory */
            /* map allocated ports to ongoing file transfers */
            std::map<int, std::shared_ptr<FileTransfer>> _ftMap;
            void _cleanFTs(void);   /* clean up completed file transfers */
            void _finishFTs(void);  /* finish all file transfers */
            Session();              /* can't create session without server */
            /* Function session thread runs to serve session */
            void run(void);
        public:
            /* get handle to session thread */
            std::thread& getThread(void);
            /* check if session is still running */
            bool isRunning(void);

            std::string& getUser(void);
            void setUser(std::string& username);

            bool isAuth(void);
            void auth(bool isAuth);

            fs::path& getCurrentDir(void);
            void setCurrentDir(fs::path& directory);

            Server& getServer(void);
            Configuration& getConfig(void);

            Socket& getSocket(void);

            Session(Server& server);
            Session(Server& server, std::string& username);
            ~Session(void);

            /* Write output to client */
            void write(std::string& output);

            /* Allocates a port for sending and receiving files 
             * throws exception if port cannot be allocated
             */
            int allocatePort(void);

            /* Writes file to specified port number */
            void writeToPort(int port, fs::path& path);

            /* Reads up to size bytes from the port 
             * and writes to the path 
             * */
            void readFromPort(int port, fs::path& path, std::uintmax_t size);

            /* Starts session thread to serve session */
            void start(void);

            /* Ends the session thread */
            void end(void);

            /* User has not issued a login command */
            bool notLoggedIn(void);
            /* User has issued a login command, but not a pass command */
            bool loggingIn(void);
            /* User has issued login and pass command */
            bool loggedIn(void);

            /* Resets Session to default settings */
            void reset(void);
    };

}   /* namespace cm */

#endif /* NETWORKING_HPP_ */ 
