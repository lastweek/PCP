#include "Exceptions.hpp"
#include "Networking.hpp"
#include <cstdlib>

namespace cm {
    Configuration::Configuration(std::string& sploitFile) :
        _base(), _userPw(), _port(0), 
        _alias(), _sploitFile(sploitFile)
    {
        parseSploit();
    }

    void Configuration::parseSploit(void) {
        std::ifstream file(_sploitFile.c_str());
        std::string line("");
        bool base_set = false;

        if(file.fail())
        {
            std::cout << "Failed to open sploit file. Make sure file and path are correct." << std::endl;
            return;	
        }
        while(!file.eof())
        {
            if (std::getline(file, line))
            {
                std::string buf;
                std::stringstream ss(line);
                std::vector<std::string> tokens;
                while(ss >> buf)
                    tokens.push_back(buf);
		if(tokens.empty())
                {
                    continue;
                }
                if(tokens.front().compare("user") == 0)
                {
		    if(tokens.size() != 3)
		    {
			throw std::runtime_error("Incorrect format for user in sploit.conf.\n");
		    }
                    _userPw.insert(std::make_pair(tokens.at(1), tokens.at(2)));
                }
                else if(tokens.front().compare("base") == 0)
                {
		    if(tokens.size() != 2)
		    {
			throw std::runtime_error("Incorrect format for base in sploit.conf.\n");
		    }
                    if (base_set) {
                        throw std::runtime_error("Multiple base definitions");
                    }
                    fs::path p = tokens.at(1);
                    p = fs::absolute(p);

                    if(!fs::is_directory(p)) {
                        throw std::runtime_error("Base is not a directory");
                    } else if(!fs::exists(p)) {
                        throw std::runtime_error("Base does not exist");
                    }
                    _base = p;
                    base_set = true;
                }
                else if(tokens.front().compare("port") == 0)
                {
		    if(tokens.size() != 2)
                    {
                        throw std::runtime_error("Incorrect format for port in sploit.conf.\n");
                    }

                    _port = std::atoi(tokens.at(1).c_str());
                    if(_port <= 0) {
                        throw std::runtime_error("Invalid port");
                    }
                }
                else if(tokens.front().compare("alias") == 0)
                {
		    if(tokens.size() < 3)
                    {
                        throw std::runtime_error("Incorrect format for alias in sploit.conf.\n");
                    }
                    std::string cmd("");
                    for(std::vector<std::string>::iterator it = std::next(tokens.begin(), 2); it != tokens.end(); ++it)
                    {
                        cmd += *it;
                        cmd += " ";
                    }
                    _alias.insert(std::make_pair(tokens.at(1), cmd));
                }
		else if(tokens.front().find_first_of("#") != 0)
		{
			// If not a comment
			throw std::runtime_error("Unsupported directive in sploit.conf.\n");
		}
            }
        }
        file.close();
        return;
    }

    bool Configuration::testPassword(std::string& username, std::string& password)
    {
        std::map<std::string, std::string>::iterator it;
        it = _userPw.find(username);
        if (it != _userPw.end())
            if(it->second.compare(password) == 0)
                return true;
        return false;
    }

    bool Configuration::isValidUser(std::string& username)
    {
        std::map<std::string, std::string>::iterator it;
        it = _userPw.find(username);
        if (it != _userPw.end())
            return true;
        return false;
    }

    int Configuration::getPort()
    {
        return _port;
    }

    fs::path& Configuration::getBase()
    {
        return _base;
    }

    std::string Configuration::getAliasCmd(std::string& alias)
    {
        std::map<std::string, std::string>::iterator it;
        it = _alias.find(alias);
        if (it == _alias.end())
        {
            return "";
        }
        return it->second;
    }
}
