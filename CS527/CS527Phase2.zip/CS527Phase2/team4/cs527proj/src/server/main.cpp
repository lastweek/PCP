#include <argp.h>
#include <csignal>
#include <iostream>
#include <sys/stat.h>

#include "sploit.hpp"

static cm::Server* server;

void kill_server(int sig) {
    std::cout << "Sploit Server Stopping....\n";
    if(server) {
       server->end();
       delete server;
       server = nullptr;
    }
    exit(0);
}

int main(int argc, char** argv) {
    std::cout << "Sploit Server Starting...\n";
    struct stat stats;
    if(stat(PROPERTIES, &stats) != 0) {
        std::cerr << "Could not find " PROPERTIES "!\n";
        std::cerr << "Exiting." << std::endl;
        return -1;
    }
    std::string propPath(PROPERTIES);
    try {
        cm::Configuration config(propPath);
        server = new cm::Server(config);
    } catch(std::exception& e) {
        std::cerr << "Error starting server: ";
        std::cerr << e.what();
        std::cerr << "Exiting." << std::endl;
        return -1;
    }
    
    if(signal(SIGTERM, kill_server) == SIG_ERR ||
            signal(SIGABRT, kill_server) == SIG_ERR ||
            signal(SIGINT, kill_server) == SIG_ERR) {
        std::cerr << "Error setting up signal handlers. ";
        std::cerr << "Exiting." << std::endl;
        delete server;
        return -1;
    }
    /* Everything is good, so let's go!!!! */
    server->start();

    return 0;
}
