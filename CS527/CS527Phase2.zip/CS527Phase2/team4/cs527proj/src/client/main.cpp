#include <iostream>
#include <csignal>
#include "sploit.hpp"


static cm::Client* client;
void kill_client(int sig);

int main(int argc, char** argv) {
    std::cout << "Sploit Client Starting...\n";
    if(argc != 3 && argc != 5) {
        std::cerr << "Usage: client server-ip server-port infile outfile\n" << std::endl;
        return 1;
    }

    std::string sIP(argv[1]);
    int sPort = atoi(argv[2]);
    std::string inFile;
    std::string outFile;
    client = new cm::Client();
    if(argc == 3)
    {
        /* User mode */
        client->setData(sIP, sPort);
    }
    if(argc == 5)
    {
        /* Automated mode */
        inFile = argv[3];
        outFile = argv[4];
	try {
            client->setData(sIP, sPort, inFile, outFile);
        } catch(std::exception& e) {
            std::cerr << "Error starting client: ";
            std::cerr << e.what();
            std::cerr << "Exiting." << std::endl;
            return -1;
        }
    }


    if(signal(SIGTERM, kill_client) == SIG_ERR || 
            signal(SIGABRT, kill_client) == SIG_ERR ||
            signal(SIGINT, kill_client) == SIG_ERR)
    {
        std::cerr << "Error setting up signal handlers.";
        std::cerr << "Exiting." << std::endl;
    }

    client->start();
    std::cout << "Sploit Client Ending....\n";
    return 0;
}

void kill_client(int sig)
{ 
    std::cerr << "Killing client. Send logout to server.\n";
    if(client)
    {
        std::string lo("logout");
        client->sendLogoutOnSig();
        delete client;
        client = nullptr;
    }

    exit(0);
}
