#include "Commands.hpp"
#include "Exceptions.hpp"

cm::LogoutCommand::LogoutCommand(cm::Session& s) :
    StateChangeCommand(s) {
        if(!s.loggedIn()) {
            throw cm::CommandException("Not logged in");
        }
    }

void cm::LogoutCommand::execute(void) {
    getSession().reset();
}
