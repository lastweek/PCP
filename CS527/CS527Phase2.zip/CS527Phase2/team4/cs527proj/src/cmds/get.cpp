#include "Commands.hpp"
#include "Exceptions.hpp"

cm::GetCommand::GetCommand(Session& s, std::string& filename) :
    AuthCommand(s), _filename(filename) {
        if(_filename.empty()) {
            throw FileNotFoundException("filename is empty");
        }
    }

void cm::GetCommand::execute(void) {
    fs::path path = _filename;
    if(path.is_relative()) {
        fs::path tmp = getSession().getCurrentDir();
        tmp /= path;
        path = tmp;
    }

    if(!fs::exists(path)) {
        throw FileNotFoundException("Could not file file");
    }

    if(fs::is_directory(path)) {
        throw FileIsDirectoryException("Requested File is a directory");
    }

    int port = 0;
    try {
        port = getSession().allocatePort();
    } catch (std::exception) {
        throw CommandException("Internal Server Error");
    }

    std::uintmax_t size = fs::file_size(path);

    /* No need to check for if port is negative, because
     * allocatePort throws an exception if one cannot
     * be allocated.
     */
    char tmp[128]; // Purposefully oversize array to avoid overflows
    sprintf(tmp, "get port: %d size: %lu", port, size);
    std::string ret(tmp);
    getSession().write(ret);

    getSession().writeToPort(port, path);
}
