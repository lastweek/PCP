#include "Commands.hpp"

void cm::WhoAmICommand::execute(void) {
    getSession().write(getSession().getUser());
}
