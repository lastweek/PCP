#include "Commands.hpp"

void cm::LSCommand::execute(void) {
    std::string cmd("ls -l ");
    cmd += getSession().getCurrentDir().string(); 
    std::string result = shell(cmd);
    getSession().write(result);
}
