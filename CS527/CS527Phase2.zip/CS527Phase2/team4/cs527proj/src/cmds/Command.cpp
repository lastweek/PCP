#include <cstdio>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <array>

#include "Commands.hpp"
#include "Exceptions.hpp"

cm::Command::~Command() { }

cm::AuthCommand::AuthCommand(Session& s) :
    Command(s) 
{
    if(!s.loggedIn()) {
        throw UnauthorizedException("User is not authorized.");
    }
}

cm::UnauthCommand::UnauthCommand(Session& s) : Command(s) {
    if(s.loggingIn()) {
        throw CommandException("Currently logging in");
    }
}

cm::StateChangeCommand::StateChangeCommand(Session& s) : Command(s) {

}

std::string cm::Command::shell(std::string& sh_cmd) {
    /* This was copied pretty much verbatim from 
     * StackOverflow: http://bit.ly/2rNoaow
     */
    std::array<char, 128> buffer;
    std::string result;
    std::shared_ptr<FILE> pipe(popen(sh_cmd.c_str(), "r"), pclose);
    if (!pipe) throw std::runtime_error("popen() failed!");
    while (!feof(pipe.get())) {
        if (fgets(buffer.data(), 128, pipe.get()) != nullptr) {
            result += buffer.data();
        }
    }
    return result;
}
