#include <experimental/filesystem>
#include "Commands.hpp"
#include "Exceptions.hpp"

cm::CDCommand::CDCommand(Session& s, std::string& newDir) :
    AuthCommand(s), _newDir(newDir) {
        if(_newDir.empty()) {
            throw FileNotFoundException("newDir is empty");
        }
    }

void cm::CDCommand::execute(void) {
    fs::path path = _newDir;
    if(path.is_relative()) {
        fs::path tmp = getSession().getCurrentDir();
        tmp /= path;
        path = tmp;
    }

    if(!fs::exists(path)) {
        throw FileNotFoundException("Could not find directory");
    } else if(!fs::is_directory(path)) {
        throw FileNotDirectoryException("Destination is not a directory");
    }

    getSession().setCurrentDir(path);
}
