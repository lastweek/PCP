#include "Exceptions.hpp"
#include "Commands.hpp"

cm::LoginCommand::LoginCommand(cm::Session& s, std::string& username) :
    StateChangeCommand(s), _username(username) {
        if(_username.empty()) {
            throw cm::InvalidUserException("Username is empty"); 
        } else if(s.loggedIn()) {
            throw cm::CommandException("User already logged in");
        }
    }

void cm::LoginCommand::execute(void) {
    getSession().setUser(_username);
}
