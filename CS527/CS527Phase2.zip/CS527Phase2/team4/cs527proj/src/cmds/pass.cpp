#include "Commands.hpp"
#include "Exceptions.hpp"

namespace cm {
    PassCommand::PassCommand(Session& s, std::string& password) :
        StateChangeCommand(s), _password(password) {
            if(!s.loggingIn()) {
                throw CommandException("Invalid State");
            }
        }

    void PassCommand::execute(void) {
        if(getSession().getUser().empty()) {
            throw UnauthorizedException("No username");
        }

        if(!getSession().getConfig().testPassword(getSession().getUser(), _password)) {
            throw UnauthorizedException("Wrong username or password"); 
        }

        getSession().auth(true);
    }
}
