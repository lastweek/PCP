#include "Commands.hpp"

void cm::WCommand::execute(void) {
    std::set<std::string> users = getSession().getServer().getConnectedUsers();
    std::string result;

    for(std::set<std::string>::iterator it = users.begin();
            it != users.end(); ++it) {
        result += *it;
        result += " ";
    }
    getSession().write(result);
}
