#include "Commands.hpp"

void cm::DateCommand::execute(void) {
    std::string cmd("date");
    std::string result = shell(cmd);
    getSession().write(result);
}
