#include "Exceptions.hpp"
#include "Commands.hpp"

cm::PingCommand::PingCommand(cm::Session& s, std::string& host) :
    UnauthCommand(s), _host(host) {
        if (_host.empty()) {
            throw cm::InvalidHostException("Host is empty"); 
        }
        char pingcmd[128];
        sprintf(pingcmd, "ping %s", host.c_str());
        _pingcmd = pingcmd;
    }

void cm::PingCommand::execute(void) {
    std::string opts = " -c 1";
    std::string full_cmd = _pingcmd + opts;
    std::string result = shell(full_cmd);
    getSession().write(result);
}
