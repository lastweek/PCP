#include <cstddef>

#include "Exceptions.hpp"
#include "Commands.hpp"

cm::MiscCommand::MiscCommand(cm::Session& s, std::string& cmd) :
    AuthCommand(s) {
        if(cmd.empty()) {
            throw EmptyCommandException("Command is empty");
        }

        trim_leading(cmd);

        std::size_t cmd_idx = cmd.find_first_of(' ');
        std::string alias = cmd.substr(0, cmd_idx);

        if(getSession().getConfig().getAliasCmd(alias).empty()) {
            throw CommandException("Command not allowed");
        }
        _cmd = cmd.replace(0, cmd_idx, getSession().getConfig().getAliasCmd(alias));

    }

void cm::MiscCommand::trim_leading(std::string& str) {
    for(std::size_t i = 0; 
            i < str.length() && std::isspace(str.at(i)); 
            i++) {
        str.erase(i);
    }
}

void cm::MiscCommand::execute(void) {
    char c_cmd[128];

    sprintf(c_cmd, "cd %s && %s",
            getSession().getCurrentDir().c_str(),
            _cmd.c_str());

    std::string full_cmd = "(";
    full_cmd += c_cmd;
    full_cmd += ")";
    std::string result = shell(full_cmd);
    getSession().write(result);
}
