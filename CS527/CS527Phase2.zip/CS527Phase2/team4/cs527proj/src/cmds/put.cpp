#include <string.h>
#include "Exceptions.hpp"
#include "Commands.hpp"

cm::PutCommand::PutCommand(cm::Session& s, std::string& filename, std::uintmax_t size) :
    AuthCommand(s), _filename(filename), _size(size) {
        if(_filename.empty()) {
            throw InvalidFileNameException("filename is empty");
        }
        if(_size == 0) {
            throw InvalidFileSizeException("file size is zero"); 
        }
    }

void cm::PutCommand::execute(void) {
    fs::path path = _filename;
    if(path.is_relative()) {
        fs::path tmp = getSession().getCurrentDir();
        tmp /= path;
        path = tmp;
    }

    int port = 0;
    try {
        port = getSession().allocatePort();
    } catch (std::exception) {
       throw CommandException("Internal Server Error"); 
    }
    char tmp[64];
    sprintf(tmp, "put port: %d", port);
    std::string ret(tmp);
    getSession().write(ret);
    getSession().readFromPort(port, path, _size);
}
