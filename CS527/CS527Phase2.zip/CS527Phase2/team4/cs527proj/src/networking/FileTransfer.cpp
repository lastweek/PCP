#include "Networking.hpp"

namespace cm {

    /*****************************************************************************/
    /* Constructor */
    /*****************************************************************************/
    FileTransfer::FileTransfer(Session& session) : 
        _session(session), _finished(false), 
        _ftSocket(4096) {

            _ctSocket.bind(0); /* bind to any available port */
            _ctSocket.listen(1);
        }

    /*****************************************************************************/
    /* get local port for file transfer */
    /*****************************************************************************/
    int FileTransfer::getPort(void) {
        return _ctSocket.getLocalPort();
    }

    /*****************************************************************************/
    /* get handle to file transfer thread */
    /*****************************************************************************/
    std::thread& FileTransfer::getThread(void) {
        return _thread;
    }

    /*****************************************************************************/
    /* set path */
    /*****************************************************************************/
    void FileTransfer::setPath(fs::path& path){
        _path = std::unique_ptr<char[]>(new char[path.string().size()]());
        sprintf(_path.get(), "%s", path.string().c_str());
    }

    /*****************************************************************************/
    /* read up to size bytes of file from client into given file path */
    /*****************************************************************************/
    void FileTransfer::read(fs::path& path, std::uintmax_t size) {
        /* Set file name */
        setPath(path);

        /* Open file for writing */
        _file.open(path.string(), std::fstream::out);

        /* Start file transfer thread */
        _thread = std::thread(&FileTransfer::_read, this, size); 
    }

    /*****************************************************************************/
    /* write file to client */
    /*****************************************************************************/
    void FileTransfer::write(fs::path& path){
        /* Set file name */
        setPath(path);

        /* Open file for writing */
        _file.open(path.string(), std::fstream::in);

        /* Start file transfer thread */
        _thread = std::thread(&FileTransfer::_write, this); 
    }

    /*****************************************************************************/
    /* internal thread function for reading incoming file */
    /*****************************************************************************/
    void FileTransfer::_read(std::uintmax_t size){
        /* Establish connection with client */
        _ctSocket.accept(_ftSocket);
        debug(_path.get()); debug("\n"); 

        /* Read file */
        _ftSocket.recvFile(_file, size);

        _endTransfer();
    }

    /*****************************************************************************/
    /* internal thread function for writing outgoing file */
    /*****************************************************************************/
    void FileTransfer::_write(void){
        /* Establish connection with client */
        _ctSocket.accept(_ftSocket);
        debug(_path.get()); debug("\n"); 

        /* Write file to client Socket */
        _ftSocket << _file;

        _endTransfer();
    }

    /*****************************************************************************/
    /* internal clean up function */
    /*****************************************************************************/
    void FileTransfer::_endTransfer(void){
        /* close file */
        _file.close();
        /* mark transfer as complete */
        _finished = true;
    }

    /*****************************************************************************/
    /* see if file transfer is complete */
    /*****************************************************************************/
    bool FileTransfer::isFinished(void){
        return _finished;
    }

} /* namespace cm */
