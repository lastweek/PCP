#include "Exceptions.hpp"
#include "Networking.hpp"
#include "Commands.hpp"
#include <vector>
#include <iostream>

namespace cm {

    void Session::checkValidUser(void) {
        if(!getConfig().isValidUser(getUser())) {
            throw InvalidUserException("User does not exist");
        }
    }

    std::string& Session::getUser(void) {
        return _username;
    }

    int Session::allocatePort(void){
        /* Create new file transfer object */
        std::shared_ptr<FileTransfer> fileTransfer(new FileTransfer(*this));

        /* Add to session file transfer map */
        _ftMap[fileTransfer->getPort()] = fileTransfer;

        /* Return file transfer port for reading/writing */
        return fileTransfer->getPort();
    }

    void Session::writeToPort(int port, fs::path& path){
        /* start file write to port */
        _ftMap[port]->write(path);
    }

    void Session::readFromPort(int port, fs::path& path, std::uintmax_t size){
        /* start file read from port */
        _ftMap[port]->read(path, size);
    }

    void Session::setUser(std::string& username) {
        /*if(!getConfig().isValidUser(username)) {
            throw InvalidUserException("User does not exist");
        }*/
        _username = username;
    }

    bool Session::isAuth(void) {
        return _auth;
    }

    void Session::auth(bool isAuth) {
        checkValidUser();
        _auth = isAuth;
    }

    fs::path& Session::getCurrentDir(void) {
        return _currentDir;
    }

    void Session::setCurrentDir(fs::path& directory) {
        _currentDir = directory;
    }

    Server& Session::getServer(void) {
        return _server;
    }

    Configuration& Session::getConfig(void) {
        return _server.getConfig();
    }

    Socket& Session::getSocket(void) {
        return _socket;
    }

    std::thread& Session::getThread(void){
        return _thread;
    }

    Session::Session(Server& server) : _server(server) {
        _auth = false;
        _run = false;
        fs::path path = getServer().getConfig().getBase();
        setCurrentDir(path);
    }

    Session::Session(Server& server, std::string& username) :
        Session::Session(server) 
    {_username = username;}

    Session::~Session() {}

    /* Write output to client */
    void Session::write(std::string& output) {
        _socket << output;
    }

    /* Starts the session thread */
    void Session::start(void) {
        _run = true;
        _thread = std::thread(&Session::run, this);
    }

    /* Ends the session thread */
    void Session::end(void) {
        _run = false;
    }

    /* check if session is still running */
    bool Session::isRunning(void){
        return _run;
    }

    /* clean up completed file transfers */
    void Session::_cleanFTs(void){
        std::shared_ptr<FileTransfer> ft;
        std::map<int, std::shared_ptr<FileTransfer>>::iterator it;
        for(it = _ftMap.begin(); it != _ftMap.end(); /*it update in loop */){
            ft = it->second;
            if(ft->isFinished()){
                if(ft->getThread().joinable()){
                    ft->getThread().join();
                }
                it = _ftMap.erase(it);
            } else {
                it++;
            }
        }
    }

    /* finish all file transfers */
    void Session::_finishFTs(void){
        std::shared_ptr<FileTransfer> ft;
        for(auto ftpair : _ftMap){
            ft = ftpair.second;
            if(ft->getThread().joinable()){
                    ft->getThread().join();
            }
        }
        _ftMap.clear();
    }

    /* Function session thread runs to serve session */
    void Session::run(void) {
        std::string client_input;
        std::shared_ptr<Command> cmd;

        while(_run == true) { 
            try {
                /* Get user input from client socket */
                _socket >> client_input;
                if(client_input.empty()){
                    end();
                    break;
                }
                /* Build command object (allocated on heap) */
                cmd = std::shared_ptr<Command>(
                    (&_server.getCommandObj(*this,client_input))
                ); 
                /* execute and free command */
                cmd->execute();
                /* clean any completed file transfers */
                _cleanFTs();
            } catch (const cm::CommandException& e) {
                _socket << std::string(e.what());
            } catch (const std::exception& e) { 
                std::cerr << e.what();
                _socket << "ERROR internal server error";
            } 
        }
        /* Session done running, finish any pending file transfers */
        _finishFTs();
    }

    bool Session::notLoggedIn(void) {
        return (getUser().empty() && !isAuth());
    }

    bool Session::loggingIn(void) {
        return (!getUser().empty() && !isAuth());
    }

    bool Session::loggedIn(void) {
        return (!getUser().empty() && isAuth());
    }

    void Session::reset(void) {
        auth(false);
        _username = "";
        fs::path path = getServer().getConfig().getBase();
        setCurrentDir(path);
    }
}
