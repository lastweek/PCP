#include <regex>

#include "Commands.hpp"
#include "Networking.hpp"
#include "Exceptions.hpp"

namespace cm {

/* Return a list of users currently connected */
std::set<std::string> cm::Server::getConnectedUsers(void) {
    std::set<std::string> currentUsers;

    for(std::shared_ptr<Session> sess : _sessions){
        if(sess->loggedIn()){
            currentUsers.insert(sess->getUser());
        }
    }

    return currentUsers;
}

cm::Configuration& cm::Server::getConfig(void) {
    return _configuration;
}

cm::Server::Server(Configuration config) : 
    _configuration(config), _mainSocket(),
    _sessions()
{}

/* Removes the user from the connected users list
             * (if the user is authenticated), and deletes the 
             * session
             */
void cm::Server::endSession(Session &s) {
    s.end();
}

/* Clean any completed sessions */
void cm::Server::_cleanSessions(void){
    std::shared_ptr<Session> sess;
    std::set<std::shared_ptr<Session>>::iterator it;
    for(it = _sessions.begin(); it != _sessions.end(); /* it update in loop */){
        sess = (*it);
        if(!sess->isRunning()){
            if(sess->getThread().joinable()){
                sess->getThread().join();
            }
            it = _sessions.erase(it);
        } else {
            it ++;
        }
    }
}

/* Add session to session table */
void cm::Server::_addSession(std::shared_ptr<Session> sptr) {
    _sessions.insert(sptr);
}

Command& cm::Server::getCommandObj(Session& s, std::string& cmd) {
    std::string buf;
    std::stringstream ss(cmd);
    std::vector<std::string> tokens;
    while(ss >> buf) {
        if(buf.find_first_of(";|") != std::string::npos) {
            throw CommandException("Only one command at a time");
        }
        tokens.push_back(buf);
    }

    if (std::regex_match (cmd, std::regex("(\\s)*(login)(\\s)+(\\S)+(\\s)*") )) {
        return *(new LoginCommand(s, tokens.at(1)));
    }
    else if (std::regex_match (cmd, std::regex("(\\s)*(pass)(\\s)+(\\S)+(\\s)*") )) {
        return *(new PassCommand(s, tokens.at(1))); 
    }
    else if (std::regex_match (cmd, std::regex("(\\s)*(ping)(\\s)+(\\S)+(\\s)*") )) {
        return *(new PingCommand(s, tokens.at(1)));
    }
    else if (std::regex_match (cmd, std::regex("(\\s)*(ls)(\\s)*") )) {
        return *(new LSCommand(s));
    }
    else if (std::regex_match (cmd, std::regex("(\\s)*(cd)(\\s)+(\\S)+(\\s)*") )) {
        return *(new CDCommand(s, tokens.at(1)));
    }
    else if (std::regex_match (cmd, std::regex("(\\s)*(get)(\\s)+(\\S)+(\\s)*") )) {
        return *(new GetCommand(s, tokens.at(1)));
    }
    else if (std::regex_match (cmd, std::regex("(\\s)*(put)(\\s)+([\\S]+(\\s)+[-]*[1-9]+[0-9]*)(\\s)*") )) {
        return *(new PutCommand(s, tokens.at(1), std::stoul (tokens.at(2),nullptr)));
    }
    else if (std::regex_match (cmd, std::regex("(\\s)*(date)(\\s)*") )) {
        return *(new DateCommand(s));
    }
    else if (std::regex_match (cmd, std::regex("(\\s)*(whoami)(\\s)*") )) {
        return *(new WhoAmICommand(s));
    }
    else if (std::regex_match (cmd, std::regex("(\\s)*(w)(\\s)*") )) {
        return *(new WCommand(s));
    }
    else if (std::regex_match (cmd, std::regex("(\\s)*(logout)(\\s)*") )) {
        return *(new LogoutCommand(s));
    }
    return *(new MiscCommand(s, cmd));
}

/* Begin accepting and dispatching client connections */
void cm::Server::start(void) {    
    /* bind to designated port, listen for connection requests */
    _mainSocket.bind(_configuration.getPort());
    _mainSocket.listen(1);
    std::shared_ptr<Session> newSession;
    while(1){ 
        /* create new session object */
        newSession = std::shared_ptr<Session>(new Session(*this));
        
        /* accept incoming connection on session socket */
        _mainSocket.accept(newSession->getSocket());
        
	    /* add session to session vector */
        _addSession(newSession);
        
        /* start thread */
        newSession->start();

        /* clean up any completed sessions */
        _cleanSessions();
    }
}

/* Signal handler for quitting, closes all clients, and
             * frees all objects, and quits gracefully
             */
void cm::Server::end(void) {
    for(std::shared_ptr<Session> sess : _sessions){
        sess->end(); /* end the session thread */
        if(sess->getThread().joinable()){
                sess->getThread().join();
        }
    }
    _sessions.clear();
}

} /* namespace cm */
