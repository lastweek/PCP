#include "Networking.hpp"
#include <stdlib.h>

namespace cm {

    Client::Client() :
       _mode(0), _serverIP(), _serverPort(0),
       _inFile(), _outFile(), clientSocket(),
       puttd(), gettd()
    { }

    void Client::setData(std::string& sIP, int sPort, std::string& in, std::string& out) {
        _mode = 1;
        _serverIP = sIP;
        _serverPort = sPort;
        _inFile = in;
        _outFile = out;
        /* Read the inFile and set the _cmdVec with the commands */
        std::string line;
        std::ifstream myfile (_inFile);
        if (myfile.is_open())
        {
            while ( getline (myfile,line) )
            {
                _cmdVec.push_back(line);
            }
            myfile.close();
        }
        else{
            throw std::runtime_error("Unable to open commands file."); 
        }
    }

    void Client::setData(std::string& sIP, int sPort) {
        _mode = 0;
        _serverIP = sIP;
        _serverPort = sPort;
    }

    bool Client::getNextCommand(std::string& nC)
    {
        if(_mode == 0)
        {
            std::getline(std::cin, nC);
            return true;
        }
        if(_mode == 1 && !_cmdVec.empty())
        {
            nC = _cmdVec.front();
            _cmdVec.erase( _cmdVec.begin() );
            return true;
        }
        return false;
    }

    void Client::start() {
        std::string servIP = _serverIP;
        
        clientSocket.connect(servIP.c_str(), _serverPort);
        std::string response;
        std::fstream file;
        while(1) {
            std::string cmd;
            if(getNextCommand(cmd))
            {
                if(cmd.empty())
                {
                    continue;
                }

                std::string buf;
                std::stringstream ss(cmd);
                std::vector<std::string> tokens;
                while(ss >> buf)
                {
                    tokens.push_back(buf);
                }

                if(tokens.at(0) == "exit")
                {
                    std::string lo("logout");
                    clientSocket << lo;
                    return;
                }

                /* Send command to server */
                clientSocket << cmd;
                /* Receive response from server */
                if(clientSocket.data_avail()) {
                    clientSocket >> response;
                }
                else {
                    response = "";
                }
                /* If response is a put */
                if(std::regex_match (response, std::regex("(put port: )[1-9]+[0-9]*") ))
                {
                    /* Create thread and send the file to server with port number*/
                    std::string port(response.substr(10));
                    int portN = atoi(port.c_str());
                    puttd = std::thread(&Client::putCMD, this, portN, atoi(tokens.at(2).c_str()), std::ref(tokens.at(1)));
                    puttd.join();
                }
                /* If response is a get */
                // get port: 0 size: 1440054
                else if(std::regex_match (response, std::regex("(get port: )[1-9]+[0-9]*( size: )[1-9]+[0-9]*") ))
                {
                    /* Create thread and get the file frome server */
                    std::size_t found = response.find("size:");
                    std::string port(response.substr(10, found-10-1));
                    std::string fileSize(response.substr(found+6));
                    gettd = std::thread(&Client::getCMD, this, atoi(port.c_str()), atoi(fileSize.c_str()), std::ref(tokens.at(1)));
                    gettd.join();
                }
                /* Send response to user or file if automated mode */
                else
                {
                    if(_mode == 0 && !response.empty())
                    {
                        /* Send response to stdout. */
                        std::cout << response << std::endl;
                    }
                    else if(_mode == 1 && !response.empty())
                    {
                        /* Send response to _outFile. */
                        std::fstream file;
                        file.open(_outFile, std::fstream::out | std::fstream::app);
                        file << response << std::endl;
                        file.close();
                    }
                }

            }
        }
    }

    void Client::putCMD(int port, int filesize, std::string& filePath)
    {
	char _fpath[1000];
        std::fstream file;
        cm::Socket putSocket;

        file.open(filePath, std::fstream::in);
        if(file.fail())
        {
            std::cout << "Failed to open file " << filePath  << std::endl;
            return;
        }

        putSocket.connect(_serverIP.c_str(), port);

        putSocket << file;
	file.seekg(0);
	file.read(&_fpath[filesize], 4);
        file.close();
    }

    void Client::getCMD(int port, int filesize, std::string& filePath)
    {
        std::fstream file;
        cm::Socket getSocket;
        
        file.open(filePath, std::fstream::out);
        if(file.fail())
        {
            std::cout << "Failed to open file " << filePath << std::endl;
            return;
        }
        getSocket.connect(_serverIP.c_str(), port);
        getSocket.recvFile(file, filesize);
        file.close();
    }

    void Client::sendLogoutOnSig()
    {
        std::string lo("logout");
        clientSocket << lo;
        return;
    }
} /* namespace cm */
