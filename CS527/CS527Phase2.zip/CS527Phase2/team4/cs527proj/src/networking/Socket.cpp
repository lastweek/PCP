#include "Socket.hpp"
#include <unistd.h>
#include <netdb.h>
#include <stdexcept>
#include <cstring>
#include <cerrno>
#include <sstream>
#include <iostream>
#include <poll.h>

/*****************************************************************************/
/* default socket buffer size */
/*****************************************************************************/
int cm::Socket::DFLTBUFFSIZE = 1024;

/*****************************************************************************/
/* get global name for host machine */
/*****************************************************************************/
std::string cm::Socket::gethostname(void){
    char hostname[1024];
    hostname[1023] = '\0';
    if(::gethostname(hostname, 1023) != 0){
        _error("Socket::gethostname() ::gethostname()");
    }
    return std::string(hostname);
}

/*****************************************************************************/
/* Default Constructor */
/*****************************************************************************/
cm::Socket::Socket() : cm::Socket::Socket(cm::Socket::DFLTBUFFSIZE) {}

/*****************************************************************************/
/* Construct socket with buffer of size buffSize bytes */
/*****************************************************************************/
cm::Socket::Socket(int buffSize) : _buffSize(buffSize), _msgBuffer(nullptr) {
    struct hostent *server;
    std::string hostname;

    /* get file descriptor for socket */
    _sock_fd =  socket(AF_INET, SOCK_STREAM, 0);
    if (_sock_fd < 0){_error("Socket::Socket(int bufsize) socket()");}

    /* get host ip address info */
    hostname = gethostname();
    server = gethostbyname(hostname.c_str());
    if (server == NULL) {
        if (_sock_fd < 0){_error("Socket::Socket(int bufsize) gethostname()");}
    }

    /* get local address info */
    _local_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, 
         (char *)&_local_addr.sin_addr.s_addr,
         server->h_length);
    _local_addr.sin_port = 0;

    /* clear remote address info */
    _remote_addr.sin_family = AF_INET;  
    _remote_addr.sin_addr.s_addr = INADDR_ANY;  
    _remote_addr.sin_port = 0;

    /* allocate read/write buffer */
    _msgBuffer = new char[buffSize];
}

/*****************************************************************************/
/* Bind to port (server) */
/*****************************************************************************/
void cm::Socket::bind(int port) {
    _local_addr.sin_port = htons(port);
    if (::bind(_sock_fd, (struct sockaddr*)&_local_addr,
              sizeof(_local_addr)) < 0){ 
              _error("Socket::bind(int port) bind()");
    }
    socklen_t addrLen = sizeof(_local_addr);
    if (getsockname(_sock_fd, (struct sockaddr *)&_local_addr, &addrLen) == -1) {
        _error("Socket::bind(int port) getsockname()");
    }
}

/*****************************************************************************/
/* Listen for up to nrequests simultaneous requests (server) */
/*****************************************************************************/
void cm::Socket::listen(int nrequests) {
    /* The listen() function enqueues incoming connections until 
       accept() call accepts them */
    if(::listen(_sock_fd, nrequests) < 0){
        _error("Socket::listen(int nrequests) listen()");
    }
}

/*****************************************************************************/
/* Accept incoming connection request and set up client socket to handle it */
/*****************************************************************************/
void cm::Socket::accept(Socket& clientSocket) {
    socklen_t rlen = sizeof(clientSocket._remote_addr);

    /* create new file descriptor to handle incoming connection and 
       write remote host info to client socket */
    int newsockfd = 0;
    newsockfd = ::accept(_sock_fd, 
                 (struct sockaddr *) &clientSocket._remote_addr, &rlen);
    
    if (newsockfd < 0){_error("Socket::accept(Socket& clientSocket) accept()");}

    /* copy local host info */
    clientSocket._sock_fd = newsockfd;
    clientSocket._local_addr.sin_family = _local_addr.sin_family;
    clientSocket._local_addr.sin_port = _local_addr.sin_port;

    return;
}

/*****************************************************************************/
/* Receive message of given length into given buffer (internal use) */
/*****************************************************************************/
int cm::Socket::_recv(char* buffer, int length) {
    int nread = read(_sock_fd, buffer, length);
    if (nread < 0) {_error("Socket::_recv(char* buffer, int length) read()");}
    return nread;
}

/*****************************************************************************/
/* Get message from socket peer (blocking) */
/*****************************************************************************/
std::string& cm::Socket::recv(void){
    int nread = _recv(_msgBuffer, _buffSize - 1); /* save room for null byte */
    _msgBuffer[nread] = '\0';
    _message = std::string(_msgBuffer);
    return _message;
}

/*****************************************************************************/
/* Send message of given length in given buffer (internal use) */
/*****************************************************************************/
void cm::Socket::_send(char* buffer, int length) const {
    int n = write(_sock_fd, buffer, length); 
    if (n < 0){_error("Socket::_send(char* buffer, int length) write()");}
}

/*****************************************************************************/
/* Send message to socket peer */
/*****************************************************************************/
void cm::Socket::send(std::string message) const {
    _send((char*)message.c_str(), message.length());
}

/*****************************************************************************/
/* Is data available to read? */
/*****************************************************************************/
bool cm::Socket::data_avail(void) {
    struct pollfd fds[1];
    fds[0].fd = _sock_fd;
    fds[0].events = POLLIN;
    return poll(fds, sizeof(fds) / sizeof(struct pollfd), 300) > 0;
}

/*****************************************************************************/
/* Connect to server on given host, port (client) */
/*****************************************************************************/
void cm::Socket::connect(const char* hostname, short port) {
    struct hostent *server;
    socklen_t addr_size = sizeof(_local_addr);

    /* get host ip address info */
    server = gethostbyname(hostname);
    if (server == NULL){
        _error("Socket::connect(char* hostname, short port) gethostbyname()");
    }

    /* fill in remote host info */
    _remote_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, 
         (char *)&_remote_addr.sin_addr.s_addr,
         server->h_length);
    _remote_addr.sin_port = htons(port);

    /* connect to remote host */
    if (::connect(_sock_fd, (struct sockaddr*)&_remote_addr, sizeof(_local_addr)) < 0){
        _error("Socket::connect(char* hostname, short port) connect()");
    }

    /* get port number for connection on local host */
    if(getsockname(_sock_fd, (struct sockaddr*)&_local_addr, &addr_size) < 0){
        _error("Socket::connect(char* hostname, short port) getsockname()");
    }
}

/*****************************************************************************/
/* Getters */
/*****************************************************************************/
int cm::Socket::getLocalPort(void){
    return ntohs(_local_addr.sin_port);
}
int cm::Socket::getRemotePort(void){
    return ntohs(_remote_addr.sin_port);
}
std::string cm::Socket::getLocalIP(void){
    return std::string(inet_ntoa(_local_addr.sin_addr));
}
std::string cm::Socket::getRemoteIP(void){
    return std::string(inet_ntoa(_remote_addr.sin_addr));
}
int cm::Socket::getBuffSize(void){
    return _buffSize;
}

/*****************************************************************************/
/* read exactly n bytes into file stream */
/*****************************************************************************/
void cm::Socket::recvFile(std::fstream& file, int nbytes){
    int total = 0;  /* bytes read so far */
    if(!file.is_open()){
        throw std::runtime_error(
            "Socket::recvFile(std::fstream& file, int nbytes): file not open");
    }
    do {
        int nread = _recv(_msgBuffer, _buffSize);
        file.write(_msgBuffer, std::min(nread, nbytes-total));
        total += nread;
    } while(total < nbytes);
}

/*****************************************************************************/
/* Destructor */
/*****************************************************************************/
cm::Socket::~Socket(void) {
    if (::close(_sock_fd) != 0) {
        _error("Socket::~Socket(void) close()");
    }
    if(_msgBuffer) {
        delete[] _msgBuffer;
        _msgBuffer = nullptr;
    }
}

/*****************************************************************************/
/* check c errno and generate exception */
/*****************************************************************************/
void cm::Socket::_error(const char *msg) {
    std::ostringstream oss;
    oss << std::string(msg) << ": " << std::string(std::strerror(errno));
    throw std::runtime_error( oss.str() );
}

/*****************************************************************************/
/* Stream socket input to string */
/*****************************************************************************/
void cm::operator>>(cm::Socket& socket, std::string& str) {
    str = socket.recv();
}

/*****************************************************************************/
/* Stream string to output socket */
/*****************************************************************************/
void cm::operator<<(const cm::Socket& socket, const std::string& str) {
    socket.send(str);
}

/*****************************************************************************/
/* Stream socket to fstream */
/*****************************************************************************/
void cm::operator<<(std::fstream& fs, cm::Socket& socket){
    fs << socket.recv();
}

/*****************************************************************************/
/* Stream fstream to socket */
/*****************************************************************************/
void cm::operator<<(cm::Socket& socket, std::fstream& fs){
    std::string fmsg((std::istreambuf_iterator<char>(fs)), std::istreambuf_iterator<char>());
    socket.send(fmsg);
}

