#include "Exceptions.hpp"

namespace cm {
	CommandException::CommandException(const char* msg) :
		std::runtime_error(std::string("ERROR ") + std::string(msg))
	{}

	UnauthorizedException::UnauthorizedException(const char* msg) :
		CommandException(msg)
	{}
	UserAuthException::UserAuthException(const char* msg) :
		CommandException(msg)
	{}
	InvalidUserException::InvalidUserException(const char* msg) :
		CommandException(msg)
	{}
	FileNotFoundException::FileNotFoundException(const char* msg) :
		CommandException(msg)
	{}
	FileNotDirectoryException::FileNotDirectoryException(const char* msg) :
		CommandException(msg)
	{}
	FileIsDirectoryException::FileIsDirectoryException(const char* msg) :
		CommandException(msg)
	{}
	InvalidHostException::InvalidHostException(const char* msg) :
		CommandException(msg)
	{}
	InvalidFileNameException::InvalidFileNameException(const char* msg) :
		CommandException(msg)
	{}
	InvalidFileSizeException::InvalidFileSizeException(const char* msg) :
		CommandException(msg)
	{}
	EmptyCommandException::EmptyCommandException(const char* msg) :
		CommandException(msg)
	{}
}
