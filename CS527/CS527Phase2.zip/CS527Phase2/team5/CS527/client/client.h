# include <stdlib.h>
# define SYSERR -1
# define OK	 1 
# define MAX_USER_NAME_SIZE 32
# define PORT_SIZE 5
# define PASSWORD_SIZE 32



