/* gcc -pthread client.c -o client */
/*FTP Client*/
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <termios.h>
#include <pthread.h>
#include "client.h"

#define BUFFER_SIZE		8192
#define CMD_SIZE		2048

int bindsock (int port, char * host_addr);
void handle_help(char *command, int auto_mode, FILE* f_out);
void *sock_create(void *arguments);
char *copy(char* a, char* b);
void print_statement(char *host_addr,int port);

struct arg {
	char *file;
	int port;
	int type;
	int size;
	char *haddr;
};


int main(int argc,char *argv[]){

	//system ("clear");
	puts ("*************************************************");
	puts ("*                                               *");
	puts ("*       Vulnerable File Transfer System!!!      *");
	puts ("*                                               *");
	puts ("*               Enter h for help                *");
	puts ("*                                               *");
	puts ("*************************************************");
  char host_addr[17];

	strncpy(host_addr, argv[1], 16);
	host_addr[16] = '\0';
	int auto_mode = SYSERR;
	FILE *f_in, *f_out;
	char port_t[6];
	strcpy(port_t, argv[2]);
	int port = atoi(port_t);

	if (argc == 5) {
		f_in = fopen(argv[3], "r");
		f_out = fopen(argv[4], "w");
		auto_mode = OK;
		printf("automode: %d\n", auto_mode);
	}
	int data_port;
	int sd_com;
	int sd_data;

	char command[CMD_SIZE];
	char buf[BUFFER_SIZE];
	char filename[20];
	int size;

	print_statement(argv[1], port);


	sd_com = bindsock(port, host_addr);

	if(sd_com < 0)
		printf("connection reject.");
	else {
		puts("Connection established.\n");
		recv(sd_com, buf, BUFFER_SIZE, 0);
		printf("\n\n%s\n", buf);
	}

  while(1){
		printf("$ ");
		memset(buf, '\0', BUFFER_SIZE);
		memset(command, '\0', CMD_SIZE);
		//printf("[%s]$ ", host_addr);
		if (auto_mode == OK) {
			if (feof(f_in)) {
				printf("End of file!!\n");
				break;
			}
			fgets(command, CMD_SIZE, f_in);
		}
		else
	   	fgets(command, CMD_SIZE, stdin);

		/* help command */

		if(command[0]=='h' && (command[1] =='\n'||command[1]==' ')){
				handle_help(command, auto_mode, f_out);
		}

		/* exit command */

		else if (strstr(command, "exit") && strlen(command) == 5){
			if (auto_mode == OK)	fprintf(f_out, "\nThank you for using this system. Bye.\n\n");
			else	printf("\nThank you for using this system. Bye.\n\n");

			if (sd_com > SYSERR) {
				strcpy(command, "disconnect");
				send(sd_com, command, CMD_SIZE, 0);
			}
			exit(EXIT_SUCCESS);
		}
		/* get file command */
		else if (!strncmp(command, "get", 3) ){
			char cmd1[10];
			char cmd2[10];
			char cmd3[10];
			char port1[10];
			char file[50];
			char message[100];
			sscanf(command, "%s %s\n", cmd1, file);
			//send command to the server
	  	send(sd_com, command, CMD_SIZE, 0);
			recv(sd_com, buf, BUFFER_SIZE, 0);
			if(strstr(buf, "ERROR") || strlen(buf) < 5){
				if (auto_mode == OK)	fprintf(f_out, "%s\n", buf);
				else printf("%s\n", buf);
			}
			else{
				puts("Preparing to receive the file...");
				//receive response according the protocol
				if (auto_mode == OK)	fprintf(f_out, "%s\n", buf);
				else printf("%s\n", buf);

				sscanf(buf, "%s %s %d %s %d\n", cmd2, cmd3, &data_port, port1, &size);

				struct arg arguments;
				arguments.file = file;
				arguments.port = data_port;
				arguments.type = 1;
				arguments.size = size;
				arguments.haddr = host_addr;

				pthread_t tid;
				pthread_create(&tid, NULL, sock_create, &arguments);
				//pthread_cancel(tid);
			}
			sleep(1);
		}

		/* put file command */

		else if (!strncmp(command, "put", 3)){
			char cmd1[10];
			char cmd2[10];
			char cmd3[10];
			char port1[10];
			char file[50];
			sscanf(command, "%s %s %d\n", cmd1, file, &size);

			FILE *filePointer = fopen(file, "r");

			if (filePointer){
				//send command to the server
	  		send(sd_com, command, CMD_SIZE, 0);
				recv(sd_com, buf, BUFFER_SIZE, 0);

				if(strstr(buf, "ERROR")){
					if (auto_mode == OK)	fprintf(f_out, "%s", buf);
					else printf("%s\n", buf);
				}
				else{
					puts("Preparing to send the file...");
					//receive response according the protocol
					if (auto_mode == OK)	fprintf(f_out, "%s", buf);
					else printf("%s\n", buf);

					sscanf(buf, "%s %s %d\n", cmd2, cmd3, &data_port);

					struct arg arguments;
					arguments.file = file;
					arguments.port = data_port;
					arguments.type = 2;
					arguments.size = size;
					arguments.haddr = host_addr;

					pthread_t tid;
					pthread_create(&tid, NULL, sock_create, &arguments);
					//pthread_cancel(tid);
					fclose(filePointer);
				}
			}
			else{
				perror("File open");
			}
			sleep(1);
		}

		else {
			send(sd_com, command, CMD_SIZE, 0);
			recv(sd_com, buf, BUFFER_SIZE, 0);
			if (auto_mode == OK)	fprintf(f_out, "%s\n", buf);
			else	printf("%s\n", buf);
		}
  	}
}

int bindsock (int port, char * host_addr) {
    	struct sockaddr_in server;
	int sock;

    	server.sin_family = AF_INET;
    	server.sin_port = htons(port);
    	server.sin_addr.s_addr = inet_addr(host_addr);

    	memset(&(server.sin_zero), '\0', 8);

    	if((sock = socket(PF_INET, SOCK_STREAM, 0)) < 3) {
		perror("socket() error");
		exit(EXIT_FAILURE);
	}

	if(connect(sock,(struct sockaddr*)&server, sizeof(server)) == SYSERR){
		perror("Connect() error");
		exit(EXIT_FAILURE);
	}

    	return sock;
}

void *sock_create(void *arguments)
{
	printf("threading...\n");
	struct sockaddr_in dataconn;
	struct arg * argument = (struct arg *) arguments;

	int datasock = bindsock(argument->port, argument->haddr);
	char *filename = argument->file;
	int size = argument->size;

	FILE *filePointer;

	//get command
	if (argument->type == 1){
		printf("Handling receiving file.\n\n");

		char *f = malloc(size);
		recv(datasock, f, size, 0); //receive file
		printf("%s\n", f);

		filePointer = fopen(filename,"w");

		if (filePointer){
    			fwrite(f, 1, size, filePointer);
    			puts("File downloaded successfully!");
		}
		else{
    			puts("ERROR: File writing interrupted.");
		}

		fclose(filePointer);
		free(f);
	}

	//put command
	else {
		printf("Handling sending file.\n\n");
		char filesend[1000000];
		filePointer = fopen(filename, "r");
		if (filePointer != NULL) {
    			size_t newLen = fread(filesend, 1, 1000000,filePointer);
    			if (ferror(filePointer) != 0) {
        			fputs("Error reading file", stderr);
    			}
			else {
				printf("%s\n", filesend);
				send(datasock, filesend, size, 0);
				puts("File uploaded successfully!");
    			}
		}
		fclose(filePointer);
	}
	return NULL;
}

void print_statement(char *host_addr, int port){
	char temp[16];
	strcpy(temp, host_addr);
	printf("Attempting a connection to %s:%d .....\n", temp, port);
}

void handle_help(char *command, int auto_mode, FILE* f_out){
	char cmd[30];
	strcpy(cmd, command);
	char help_message[1024] = "Available commands are:\n"
																		"\t connect- To connect to the FTP server.\n"
																		"\t\t\t ex) connect $HOST $PORT\n"
																		"\t login       - To login to the system.\n"
																		"\t pass        - To provide a password for the specific username.\n"
																		"\t ping        - check if a host is alive.\n"
																		"\t\t\t ex) ping $HOST\n"
																		"\t ls  - lists the available files in the current working directory.\n"
																		"\t\t\t ex) ls -l\n"
																		"\t cd  - changes the current working directory.\n"
																		"\t\t\t ex) cd $DIRECTORY\n"
																		"\t get - Retrieves a file from the current working directory.\n"
																		"\t\t\t ex) get $FILENAME\n"
																		"\t put - Sends the specified file from the current local working directory.\n"
																		"\t\t\t ex) put $FILENAME $SIZE\n"
																		"\t date        - Returns the output from the Unix date command.\n"
																		"\t whoami- Returns the name of the currently logged in user.\n"
																		"\t w   - Returns a list of each logged in user on a single line space separated.\n"
																		"\t logout- Logs the user out of her session.\n"
																		"\t exit        - Exits the program.\n";
	printf("%s", help_message);
	return;
}
