#include "sploit.h"
#include <stdio.h>

/*
 * Compares two binary values
 * Returns 1 when they are equal, otherwise returns -1
 */
int binary_compare(unsigned char * op1, unsigned int sz1, unsigned char * op2, unsigned int sz2){
  int i ;
  for(i=0;i<sz2;++i){
    if(op1[i]==op2[i])continue;
    return -1;
  }
  return 1 ;
}

/*
 * find number of users and numberof commands
 */
void set_num_users_cmds(char *filename){
  FILE *fin = fopen(filename, "r");
  if (fin == NULL){
    printf("Failed to open sploit.conf\n");
    exit(EXIT_FAILURE);
  }
  numUsers = 0;
  numCommands = 0;
  char line[MAX_LINE_SIZE];
  unsigned char *ptr;
  while(fgets(line, MAX_LINE_SIZE, fin)){
    if (line[0]!='\n'&&line[0]!='#'){
      ptr = strtok(line, " ");
      if (binary_compare("user",4,ptr,strlen(ptr))==1) numUsers++;
      else if (binary_compare("alias",5,ptr,strlen(ptr))==1) numCommands++;
    }
  }
  fclose(fin);
}


// Parse the sploit.h file and fill in the global variables
void parse_sploit(char *filename) {
  set_num_users_cmds(filename);
  FILE *fin = fopen(filename, "r");
  if (fin == NULL){
    printf("Failed to open sploit.conf\n");
    exit(EXIT_FAILURE);
  }
  unsigned char uname[MAX_USER_NAME_SIZE];
  unsigned char password[MAX_PASSWORD_SIZE];
  unsigned char tport[PORT_SIZE+1];
  unsigned char cname[MAX_CNAME_SIZE];
  unsigned char cmd[MAX_CMD_SIZE];
  unsigned char params[MAX_PARAMS_SIZE];
  char *ptr;
  char tbase[BASE_SIZE+1];
  char line[MAX_LINE_SIZE];
  int counter, i = 0, j = 0;
  userlist_ptr = mmap(NULL, sizeof(User)*numUsers, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, 0, 0);
  commandlist = (Command*)malloc(sizeof(Command)*numCommands);
  if (userlist_ptr == MAP_FAILED) {
    perror("mmap(2) failed");
    exit(EXIT_FAILURE);
  }
  userlist = (User*)userlist_ptr;
  while(fgets(line, MAX_LINE_SIZE, fin)){
    if (line[0]!='\n'&&line[0]!='#'){
      counter = 0;
      ptr = strtok(line, " ");
      switch (line[0]){
        case 'u':
          while(ptr){
            if (counter==0){
              if (binary_compare("user",4,ptr,strlen(ptr))==-1) break;
            }
            else if (counter==1) strcpy(uname, ptr);
            else if (counter==2){
              strncpy(password, ptr, strlen(ptr)-1);
              password[strlen(ptr)-1]='\0';
              strcpy(userlist[i].uname, uname);
              strcpy(userlist[i].pass, password);
              userlist[i].isLoggedIn = false;
              i++;
            }
            ++counter;
            ptr = strtok(NULL, " ");
          }
          break;
        case 'p':
          while(ptr){
            if(counter==0){
              if (binary_compare("port",4,ptr,strlen(ptr))!=1) break;
            }
            if (counter==1) {
              strncpy(tport, ptr, strlen(ptr)-1);
              tport[strlen(ptr)-1]='\0';
              port = (unsigned short)atoi(tport);
            }
            ++counter;
            ptr = strtok(NULL, " ");
          }
          break;
        case 'a':
          while(ptr){
            if(counter==0){
              if (binary_compare("alias",5,ptr,strlen(ptr))!=1) break;
            }
            else if (counter==1) strcpy(cname, ptr);
            else if (counter==2) strcpy(cmd, ptr);
            else if (counter==3) strcpy(params, ptr);
            else if (counter>3){
              strcat(params, " ");
              strcat(params, ptr);
            }
            ptr = strtok(NULL, " ");
            if (ptr==NULL&&counter==2) {
              cmd[strlen(cmd)-1]='\0';
              strcpy(commandlist[j].cname, cname);
              strcpy(commandlist[j].cmd, cmd);
              strcpy(commandlist[j].params, "\0");
              j++;
            }
            else if(ptr==NULL&&counter>=3){
              params[strlen(params)-1]='\0';
              strcpy(commandlist[j].cname, cname);
              strcpy(commandlist[j].cmd, cmd);
              strcpy(commandlist[j].params, params);
              j++;
            }
            counter++;
          }
          break;
        case 'b':
          while(ptr){
            if(counter==0){
              if (binary_compare("base",4,ptr,strlen(ptr))!=1) break;
            }
            if (counter==1) {
              strncpy(tbase, ptr, strlen(ptr)-1);
              tbase[strlen(ptr)-1]='\0';
              strcpy(base, tbase);
            }
            ++counter;
            ptr = strtok(NULL, " ");
          }
          break;
        default:
          break;
      }
    }
  }
  fclose(fin);
}

/*
 * used to parse recevied command on the server side
 */
Command *parse_command(char *buf, int read_size){
  Command *output = malloc(sizeof(Command));
  memset(output, '\0', sizeof(Command));
  buf[read_size] = '\0';
  char *ptr;
  int counter = 0;
  int params_len = 0;
  ptr = strtok(buf, " ");
  while (ptr){
    if (ptr!=NULL&&counter==0) {
      params_len += strlen(ptr);
      if (strlen(ptr)<MAX_CMD_SIZE) {strcpy(output->cmd, ptr);}
      else return NULL;
    }
    else if (counter==1) {
      params_len += strlen(ptr);
      if (params_len<MAX_PARAMS_SIZE){
        strcpy(output->params, ptr);
      }
      else return NULL;
    }
    else if(counter>1){
      params_len += strlen(ptr)+1;
      if (params_len<MAX_PARAMS_SIZE){
        strcat(output->params, " ");
        strcat(output->params, ptr);
      }
      else return NULL;
    }
    ptr = strtok(NULL, " ");
    if (ptr==NULL&&counter==0) {
      output->cmd[strlen(output->cmd)-1]='\0';
      strcpy(output->params, "\0");
    }
    else if (ptr==NULL&&counter>0){
      output->params[strlen(output->params)-1]='\0';
    }
    counter++;
  }
  return output;
}

//report error
int rpt_err(char *arg){
	char check[50];
	sscanf(arg, "%s", check);
	printf("%s\n", check);
	if(strstr(check, "%")){
		return SYSERR;
	}
	else {
		return OK;
	}
}

// Used to deallocate userlist and cmdlist
void free_userlist() {
  munmap(userlist, sizeof(User)*numUsers);
}

void free_commandlist() {
  free(commandlist);
}

// used to print user list
void print_user(){
  int i;
  for (i=0;i<numUsers;i++){
    printf("(%s,%s), ",userlist[i].uname, userlist[i].pass);
  }
  printf("\n");
}

void print_command(){
  int i;
  for (i=0;i<numCommands;i++){
    if(strlen(commandlist[i].params)>0){
      printf("(%s, %s, %s), ", commandlist[i].cname, commandlist[i].cmd, commandlist[i].params);
    }
    else{
      printf("(%s, %s), ",commandlist[i].cname, commandlist[i].cmd);
    }
  }
  printf("\n");
}

User *find_user(char *uname){
  int i;
  for (i = 0; i < numUsers; i++){
    if((binary_compare(uname, strlen(uname), userlist[i].uname, strlen(userlist[i].uname))==1) && (strlen(uname) == strlen(userlist[i].uname))){
      return &(userlist[i]);
    }
  }
  printf("ERROR: User does not exist\n");
  return NULL;
}

Command *find_command(char *cname){
  int i;
  for (i = 0; i < numCommands; i++){
    if(binary_compare(cname, strlen(cname), commandlist[i].cname, strlen(commandlist[i].cname))==1){
      return &(commandlist[i]);
    }
  }
  return NULL;
}

/*
int main(){
  char *ptr = malloc(21);
  int size = 20;
  char *tmp = "pass 1234 5678 9012\n";
  strcpy(ptr, tmp);
  Command *cmd = parse_command(ptr, size);
  printf("%s, %s\n", cmd->cmd, cmd->params);
}*/
