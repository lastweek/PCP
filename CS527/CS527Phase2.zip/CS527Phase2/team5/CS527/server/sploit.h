#ifndef SPLOIT_H
#define SPLOIT_H

#define DEBUG true
#define PORT_SIZE 7
#define MAX_LINE_SIZE 100
#define MAX_USER_NAME_SIZE 33
#define MAX_PASSWORD_SIZE 31
#define MAX_CNAME_SIZE 33
#define MAX_CMD_SIZE 512
#define MAX_PARAMS_SIZE 512
#define BASE_SIZE 100
#define SYSERR	-1
#define OK	 1
#define QUEUELEN 10
#define DATASIZE 8192
#define FILENAME "sploit.conf"

#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdbool.h>
#include <pthread.h>
#include <assert.h>
#include <unistd.h>
#include <netinet/in.h>
#include <netdb.h>
#include <signal.h>

typedef struct user {
    unsigned char uname[MAX_USER_NAME_SIZE];
    unsigned char pass[MAX_PASSWORD_SIZE];
    bool isLoggedIn;
} User;



typedef struct command {
    unsigned char cname[MAX_CNAME_SIZE];
    unsigned char cmd[MAX_CMD_SIZE];
    unsigned char params[MAX_PARAMS_SIZE];
} Command;


void *userlist_ptr;
User *userlist;
Command *commandlist;
char base[BASE_SIZE];
int numCommands;
int numUsers;
int rpt_err(char *arg);
unsigned short port;
Command *find_command(char *cname);
Command *parse_command(char *buf, int read_size);
User *find_user(char *uname);
int binary_compare(unsigned char * op1, unsigned int sz1, unsigned char * op2, unsigned int sz2);
void free_userlist();
void free_base();
void free_commandlist();
void parse_sploit(char *filename);
void print_command();
void print_user();
#endif
