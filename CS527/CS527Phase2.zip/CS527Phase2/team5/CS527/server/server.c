#include "sploit.h"
#include <stdio.h>
#define MAX_PASSW0RD_SIZE	33

int bindsock (int port);
void *sock_create(void *port);

struct arg {
	char *filepath;
	int port;
	int type;
	int size;
	//char *pwd;
};

// Server side REPL given a socket file descriptor
void *connection_handler(int sockfd) {

	// get the position (for cd & ls)
	char *current_pwd = base;
        if (current_pwd[-1] != '/') {
            current_pwd[strlen(current_pwd)] = '/';
            current_pwd[strlen(current_pwd)] = '\0';
        }
	int pwd_layer = 0;
	chdir(base);
	system("pwd");

    char buf[DATASIZE];
    char filename[50];
    bool logged_in = false;
    char datasend[DATASIZE];
    int size;
    struct stat obj;

    //Get the socket descriptor
    int sock = sockfd;
    int read_size;
    int status;
    char *return_message;
    User *current_user = NULL;
    Command *command;
    Command *alias;
    char *command_tmp;

    //Receive a message from client
    while(1){
			memset(buf, '\0', DATASIZE);
			memset(filename, '\0', 50);
			memset(datasend, '\0', DATASIZE);
      read_size = recv(sock , buf , DATASIZE , 0);
			if(read_size == 0){
        current_user->isLoggedIn=false;
        current_user=NULL;
        printf("Connection closed by client\n");
        puts("Client disconnected");
        fflush(stdout);
        command=NULL;
        free(command);
        return 0;
      }
			else if(read_size == -1){
				current_user->isLoggedIn=false;
				current_user=NULL;
        perror("recv failed");
        exit(-1);
      }
      command = parse_command(buf, read_size);
      alias = find_command(command->cmd);

      if (alias!=NULL){
				if (current_user==NULL||current_user->isLoggedIn==false){
					if (current_user==NULL){
						return_message = "ERROR: please login fisrt.\n";
						send(sock, return_message, strlen(return_message)+1, 0);
					}
					else{
						return_message = "ERROR: pass must directly follows login.\n";
						send(sock, return_message, strlen(return_message)+1, 0);
					}
				}
				else{
					if (strlen(command->params)>0){
						strcat(alias->params, command->params);
					}
				  FILE *tmp_fp;
				  char *path = malloc(100);
				  command_tmp = malloc(MAX_PARAMS_SIZE+MAX_CMD_SIZE);
				  strcpy(command_tmp, alias->cmd);
				 	strcat(command_tmp, " ");
				  strcat(command_tmp, alias->params);
				  tmp_fp = popen(command_tmp, "r");
				  if (tmp_fp == NULL){
				    printf("fp = NULL\n");
				    strcpy(datasend, "ERROR: command error\n");
				    send(sock, datasend, DATASIZE,0);
				  }
				  else {
				   strcpy(datasend, "");
				   while (fgets(path, 100, tmp_fp) != NULL){
				     printf("%s", path);
				     strcat(datasend, path);
				   }
				  }
				  send(sock, datasend, DATASIZE,0);
					path = NULL;
					command_tmp = NULL;
					free(command_tmp);
					free(path);
				}
				continue;
			}

      if (!strcmp(command->cmd, "login")){
        if (!strlen(command->params)){
          return_message = "ERROR: illegal command.\n";
          send(sock, return_message, strlen(return_message)+1, 0);
        }
        else if (current_user==NULL){
          char username[MAX_USER_NAME_SIZE];
          current_user = find_user(command->params);
          printf("%s1\n", command->params);
          if (current_user != NULL){
            if (current_user->isLoggedIn==true){
              printf("user %s has already logged_in\n", command->params);
              return_message = "user has already logged in\n";
              current_user = NULL;
              send(sock, return_message, strlen(return_message)+1, 0);
            }
            else{
              printf("user name %s verified\n", command->params);
              return_message = "username verified\n";
              send(sock, return_message, strlen(return_message)+1, 0);
            }
          }
          else{
            return_message = "ERROR: user not found.\n";
            send(sock, return_message, strlen(return_message)+1, 0);
          }
        }
        else{
          return_message = "ERROR: pass must directly follows login.\n";
          send(sock, return_message, strlen(return_message)+1, 0);
        }
        continue;
      }

      else if(!strcmp(command->cmd, "pass")){
        if (current_user==NULL){
          return_message = "ERROR: pass must directly follows login.\n";
          send(sock, return_message, strlen(return_message)+1, 0);
        }
        else if(!strlen(command->params)){
          return_message = "ERROR: illegal command.\n";
          send(sock, return_message, strlen(return_message)+1, 0);
        }
        else{
	char stored_pass[MAX_PASSWORD_SIZE];
	char input_pass[MAX_PASSWORD_SIZE];
	snprintf(stored_pass,  MAX_PASSW0RD_SIZE, "%s", current_user->pass);
	snprintf(input_pass,  MAX_PASSW0RD_SIZE, "%s", command->params);

	if ((binary_compare(input_pass, strlen(input_pass), stored_pass, strlen(stored_pass))==OK) 
		&& (strlen(command->params) <= MAX_PASSW0RD_SIZE)){
            return_message = "Login authorized.\n";
            send(sock, return_message, strlen(return_message)+1, 0);
            current_user->isLoggedIn = true;
          }
          else{
            return_message = "ERROR: password doesn't match.\n";
            send(sock, return_message, strlen(return_message)+1, 0);
          }
        }
        continue;
      }

      else if(!strcmp(command->cmd, "logout")){
        if (current_user==NULL||current_user->isLoggedIn==false){
          if (current_user==NULL){
            return_message = "ERROR: please login fisrt.\n";
            send(sock, return_message, strlen(return_message)+1, 0);}
          else{
            return_message = "ERROR: pass must directly follows login.\n";
            send(sock, return_message, strlen(return_message)+1, 0);
          }
        }
        else{
          current_user->isLoggedIn = false;
          current_user = NULL;
          return_message = "Logged out sucessfully.\n";
          send(sock, return_message, strlen(return_message)+1, 0);
    			puts("Logged out.");
        }
        continue;
  	 }

		else if(!strcmp(command->cmd, "ping")){
			char *ping_cmd;
			char *hostname;
			ping_cmd = command->cmd;
			hostname = command->params;
			strcat(ping_cmd, " ");
			strcat(ping_cmd, hostname);
			strcat(ping_cmd, " -c 1");
			//printf("ping_cmd: <%s>\n");
			FILE *tmp_fp;
			char path[100];
			tmp_fp = popen(ping_cmd, "r");
			if (tmp_fp == NULL){
				printf("fp = NULL\n");
				strcpy(datasend, "\n\tping command error\n");
			} else {
				strcpy(datasend, "");
				while (fgets(path, 100, tmp_fp) != NULL){
					printf("%s", path);
					strcat(datasend, path);
				}
			}
			send(sock, datasend, DATASIZE,0);
		}

		else if(!strcmp(command->cmd, "cd")){
			if (current_user==NULL){
				if(current_user->isLoggedIn==false){
					return_message = "ERROR: pass must directly follows login.\n";
					send(sock, return_message, strlen(return_message)+1, 0);
				}
				else{
					return_message = "ERROR: please login first.\n";
					send(sock, return_message, strlen(return_message)+1, 0);
				}
			}
			else {
				char* target_dir;
				target_dir = command->params;
				if (strcmp(target_dir, "")==0){
					printf("go to base\n");
					while(pwd_layer > 0){
						chdir("..");
						pwd_layer--;
					}
					strcpy(current_pwd, base);
	
					FILE *fp;
					char message[100];
					strcpy(datasend, "");
					//strcpy(datasend, "current_pwd: ");
					fp = popen("/bin/pwd", "r");
                                        fgets(message, sizeof(message)-1, fp);
                                        printf("Current full pwd: %s.\n\n\n", message);
                                        //strcat(datasend, current_pwd);
                                        send(sock, datasend, DATASIZE, 0);
				}else{
					char tmp_dir[1024];
					int target_layer = pwd_layer;
					strcpy(tmp_dir, current_pwd);
					if (strcmp(current_pwd, base)!=0){
						strcpy(tmp_dir, current_pwd);
					}
					else{
						memset(tmp_dir,'\0',1024);
					}
					int accessible = OK;
					int tmp;
					char *token;
					token = strtok(target_dir, "/");
					while (token != NULL){
						if (strcmp(token, "..") == 0){
							if (target_layer <= 0){
								accessible = SYSERR;
								break;
							}
							tmp = strlen(tmp_dir)-2;
                	                                while (tmp_dir[tmp]!='/')	tmp--;
                        	                        tmp_dir[tmp+1] = '\0';
							target_layer--;
						} else {
							target_layer++;
							strcat(tmp_dir, token);
        	                                        strcat(tmp_dir, "/");
						}
						token = strtok(NULL, "/");
					}
					FILE *fp;
					char message[100];
					if (accessible == SYSERR){
						strcpy(datasend, "cd error, can't access\n");
					} else {
						system("pwd");
						printf("chmod: <%s>\n", target_dir);
						tmp = chdir(target_dir);
						if (tmp == -1) {
							strcpy(datasend, "cd error, can't chdir\n current_pwd: ");
							printf("tmp_dir: <%s>\n", tmp_dir);
						} else {
							pwd_layer = target_layer;
		                                        strcpy(current_pwd, tmp_dir);
							strcpy(datasend, "");
						}
					}
					fp = popen("/bin/pwd", "r");
	                                fgets(message, sizeof(message)-1, fp);
					printf("Current full pwd: %s.\n", message);
					send(sock, datasend, DATASIZE, 0);
				}
			}
	}


		else if(!strcmp(command->cmd, "ls")){
	    printf("in l\n");
	    if (current_user==NULL||current_user->isLoggedIn==false){
	      if (current_user==NULL){
	        return_message = "ERROR: please login fisrt.\n";
	        send(sock, return_message, strlen(return_message)+1, 0);          }
	      else{
	        return_message = "ERROR: pass must directly follows login.\n";
	        send(sock, return_message, strlen(return_message)+1, 0);
	      }
	    }
	    else {
	      FILE *tmp_fp;
	      char path[300];
              char tmp_cmd[300] = "ls -l ";
              //strcat(tmp_cmd, command->params);
              tmp_fp = popen(tmp_cmd, "r");
	      if (tmp_fp == NULL){
	        printf("fp = NULL\n");
	        strcpy(datasend, "\nERROR: ls command error\n");
	        send(sock, datasend, DATASIZE,0);
	      }
	      else {
		      strcpy(datasend, "");
		      while (fgets(path, 100, tmp_fp) != NULL){
			        printf("%s", path);
			        strcat(datasend, path);
		      }
	      }
	      send(sock, datasend, DATASIZE,0);
		  }
	    continue;
		}
		else if(!strcmp(command->cmd, "date")){
	    if (current_user==NULL||current_user->isLoggedIn==false){
	      if (current_user==NULL){
	        return_message = "ERROR: please login fisrt.\n";
	        send(sock, return_message, strlen(return_message)+1, 0);          }
	      else{
	        return_message = "ERROR: pass must directly follows login.\n";
	        send(sock, return_message, strlen(return_message)+1, 0);
	      }
	    }
	    else {
	  	  FILE *tmp_fp;
		    char date[30];
		    tmp_fp = popen("/bin/date", "r");
		    if (tmp_fp == NULL){
	        printf("fp = NULL\n");
	        strcpy(datasend, "\n\tdate command error\n");
	      }
	      else {
	        fgets(date, sizeof(date)-1, tmp_fp);
	        printf("date: <%s>\n", date);
		      strcpy(datasend, "The current system time is: ");
	        strcat(datasend, date);
	        strcat(datasend, "\n");
	      }
	      send(sock, datasend, DATASIZE,0);
		  }
	  continue;
	  }
	  else if(!strcmp(command->cmd, "whoami")){
	    if (current_user==NULL||current_user->isLoggedIn==false){
	      if (current_user==NULL){
	        return_message = "ERROR: please login fisrt.\n";
	        send(sock, return_message, strlen(return_message)+1, 0);          }
	      else{
	        return_message = "ERROR: pass must directly follows login.\n";
	        send(sock, return_message, strlen(return_message)+1, 0);
	      }
	    }
	    else{
	      char temp[strlen(current_user->uname)+2];
	      strcpy(temp, current_user->uname);
	      strcat(temp, "\n");
	      send(sock, temp, strlen(temp)+1, 0);
	    }
	  }
	  else if(!strcmp(command->cmd, "w")){
	    if (current_user==NULL||current_user->isLoggedIn==false){
	      if (current_user==NULL){
	        return_message = "ERROR: please login fisrt.\n";
	        send(sock, return_message, strlen(return_message)+1, 0);          }
	      else{
	        return_message = "ERROR: pass must directly follows login.\n";
	        send(sock, return_message, strlen(return_message)+1, 0);
	      }
	    }
	    else{
	      char* temp_users = malloc(numUsers*(MAX_USER_NAME_SIZE+2));
	      memset(temp_users, '\0', numUsers*(MAX_USER_NAME_SIZE+2));
	      memset(datasend, '\0', DATASIZE);
	      int i;
	      for (i=0;i<numUsers; i++){
	        if (userlist[i].isLoggedIn==true){
	          strcat(temp_users, userlist[i].uname);
	          if(i!=numUsers-1){
	            strcat(temp_users," ");
	          }
	        }
	      }
	      strcat(temp_users,"\n");
	      printf("logged in users are %s: ",temp_users);
	      send(sock, temp_users, strlen(temp_users)+1, 0);
	      temp_users=NULL;
	      free(temp_users);
	    }
	  }
		else if(!strcmp(command->cmd, "get")){
			if (current_user==NULL||current_user->isLoggedIn==false){
				if (current_user==NULL){
					return_message = "ERROR: please login fisrt.\n";
					send(sock, return_message, DATASIZE, 0);
				}
				else{
					return_message = "ERROR: pass must directly follows login.\n";
					send(sock, return_message, DATASIZE, 0);
				}
			}
			else{
				if(rpt_err(command->params) == OK){
					puts("Creating the second connection for the file transfer...");
					srand(time(0));
					int dataport = 40000 + rand() % 10000;
					char *filename = command->params;

					char filepath[50];
					if (strcmp(current_pwd, base)!=0){
						strcpy(filepath, current_pwd);
						strcat(filepath, filename);
					}
					else 	{
						strcpy(filepath, "");
						strcat(filepath, filename);
					}

					stat(filepath, &obj);

					size = obj.st_size;
					FILE *filePointer = fopen(filepath, "r");

					if(filePointer){
						struct arg arguments;
						arguments.filepath = filepath;
						arguments.port = dataport;
						arguments.type = 1;
						arguments.size = size;

						pthread_t tid;
						pthread_create(&tid, NULL, sock_create, &arguments);
						sleep(1);

						sprintf(datasend, "get port: %d size: %d", dataport, size);
						printf("%s\n", datasend);
						send(sock, datasend, DATASIZE, 0);
						fclose(filePointer);
					}
					else {
						perror("fopen");
						char err[MAX_PARAMS_SIZE];
						snprintf(err, 23, "ERROR: No such file-> ");
						snprintf(err + strlen(err), DATASIZE, command->params);
						snprintf(datasend, DATASIZE, err);
						printf("%s\n", datasend);
						send(sock, datasend, DATASIZE, 0);
					}
				}
				else {
					return_message = "ERROR: Invalid filename.\n";
					snprintf(datasend, DATASIZE, return_message);
					send(sock, datasend, DATASIZE, 0);
				}
			}
		}

		else if(!strcmp(command->cmd, "put")){
			if (current_user==NULL||current_user->isLoggedIn==false){
				if (current_user==NULL){
					return_message = "ERROR: please login fisrt.\n";
					send(sock, return_message, DATASIZE, 0);
				}
				else{
					return_message = "ERROR: pass must directly follows login.\n";
					send(sock, return_message, DATASIZE, 0);
				}
			}
			else{
				if(rpt_err(command->params) == OK){
					puts("Creating the second connection for the file transfer...");
					srand(time(0));
					int dataport = 40000 + rand() % 10000;

					sscanf(command->params, "%s %d", filename, &size);

					char filepath[50];
					if (strcmp(current_pwd, base)!=0){
						strcpy(filepath, current_pwd);
						strcat(filepath, filename);
					}
					else 	{
						strcpy(filepath, "");
						strcat(filepath, filename);
					}

					struct arg arguments;
					arguments.filepath = filepath;
					arguments.port = dataport;
					arguments.type = 2;
					arguments.size = size;

					pthread_t tid;
					pthread_create(&tid, NULL, sock_create, &arguments);
					sleep(1);

					sprintf(datasend, "put port: %d", dataport);
					printf("%s\n", datasend);
					send(sock, datasend, DATASIZE, 0);
				}
				else {
					return_message = "ERROR: Invalid filename.\n";
					snprintf(datasend, DATASIZE, return_message);
					send(sock, datasend, DATASIZE, 0);
				}
			}
		}
	  else {
	    strcpy(datasend, "ERROR: command not recognized!\n");
	    send(sock, datasend, DATASIZE,0);
	  }
   command = NULL;
	 }
}


int main(){
  parse_sploit(FILENAME);
  system ("clear");
  puts ("*************************************************");
  puts ("*                                               *");
  puts ("*       Vulnerable File Transfer Server!!!      *");
  puts ("*                                               *");
  puts ("*************************************************");
  puts ("");

  int server_sockfd, client_sockfd;
  int server_len, client_len;
  struct sockaddr_in client_address;

  server_sockfd = bindsock(port);
  signal(SIGCHLD, SIG_IGN);

  while(1) {
    printf("server waiting for connection\n");
    /* Accept connection. */
    client_len = sizeof(client_address);
    if((client_sockfd = accept(server_sockfd,(struct sockaddr *)&client_address, &client_len))<0){
      perror ("accept() failed\n");
      exit(EXIT_FAILURE);
    }
    char greeting[50];
    strcpy(greeting, "Welcome to vulnerable server!");
    send(client_sockfd, greeting, DATASIZE,0);
    /* Fork to create a process for this client and perform a test to see
    whether we're the parent or the child. */
    if(fork() == 0) {
      close(server_sockfd);
      connection_handler(client_sockfd);
      close(client_sockfd);
      exit(EXIT_SUCCESS);
    }
    /* Otherwise, we must be the parent and our work for this client is
    finished. */
    close(client_sockfd);
  }
}

int bindsock (int port) {
    	struct sockaddr_in server;
    	int sock;

    	server.sin_family = AF_INET;
    	server.sin_port = htons(port);
    	server.sin_addr.s_addr = INADDR_ANY;

    	memset(&(server.sin_zero), '\0', 8);

    	if((sock = socket(PF_INET, SOCK_STREAM, 0)) < 3) {
		perror("socket() error");
	}

  	int server_len = sizeof(server);

	if (bind(sock, (struct sockaddr *)&server, server_len) < 0){
		perror ("bind() failed");
	}

	if (listen(sock, QUEUELEN) < 0){
		perror ("listen() failed");
	}

    	return sock;
}

void *sock_create(void *arguments)
{
	printf("threading...");
	struct sockaddr_in dataconn;
	struct arg * argument = (struct arg *) arguments;

	int datasock = bindsock(argument->port);
	char *filepath = argument->filepath;
	int size = argument->size;

	int dataconnlen = sizeof(struct sockaddr_in);
    	int slavesock = accept(datasock, (struct sockaddr*)&dataconn, &dataconnlen);
	printf("slave socket created %d\n", slavesock);
	FILE * filePointer;

	//put command
	if (argument->type == 2){
		char *f = malloc(size);
		recv(slavesock, f, size, 0); //receive file

		filePointer = fopen(filepath,"w");

		if (filePointer){
			fwrite(f, 1, size, filePointer);
			puts("File downloaded successfully!");
		}
		else{
			perror("fopen");
		}

		fclose(filePointer);
		free(f);
	}

	//get command
	else {
		char filesend[1000000];
		filePointer = fopen(filepath,"r");

		if (filePointer != NULL) {
    			size_t newLen = fread(filesend, 1, 1000000, filePointer);
    			if ( ferror( filePointer ) != 0 ) {
        			fputs("Error reading file", stderr);
    			}
			else {
				printf("%s\n", filesend);
				send(slavesock, filesend, size, 0);
				puts("File sent successfully!");
    			}
		}
		else{
			perror("fopen");
		}
	}
	close(datasock);
	close(slavesock);

	return NULL;
}
